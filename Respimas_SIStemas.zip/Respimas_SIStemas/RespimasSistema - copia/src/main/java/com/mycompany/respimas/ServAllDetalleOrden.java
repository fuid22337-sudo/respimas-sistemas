/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.respimas;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ianac
 */
@WebServlet("/ServAllDetalleOrden")
public class ServAllDetalleOrden extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String numOrden = request.getParameter("num_orden");

        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html><html><head><title>Detalle Orden " + numOrden + "</title>");
            out.println("<link rel='stylesheet' type='text/css' href='estilos.css'>");
            out.println("</head><body>");
            out.println("<header class='main-header'>");
            out.println("<div class='logo-area'><div class='company-text'><h2>RESPIMAS</h2></div></div>");
            out.println("<div class='user-area'>");
            out.println("<span class='user-greeting'>👋 <strong>" + request.getSession().getAttribute("nombre") + "</strong> (" + request.getSession().getAttribute("usuario") + ") | Rol: " + request.getSession().getAttribute("rol") + "</span>");
            out.println("<a href='ServLogout' class='logout-btn' onclick='return confirm(\"¿Cerrar sesión?\")'>Cerrar sesión</a>");
            out.println("</div>");
            out.println("</header>");
            out.println("<div class='container'>");
            out.println("<h2>Detalle de Orden: " + numOrden + "</h2>");
            out.println("<a href='formAltaDetalleOrden2.jsp?num_orden=" + numOrden + "' class='accion-agregar'>➕ Agregar producto a orden</a>");

            try (Connection conn = ConexionBD.getConnection();
                 PreparedStatement pst = conn.prepareStatement(
                     "SELECT d.*, p.descripcion FROM DETALLE_ORDEN d " +
                     "INNER JOIN PRODUCTO p ON d.SKU = p.SKU " +
                     "WHERE d.num_orden = ?")) {
                pst.setString(1, numOrden);
                ResultSet rs = pst.executeQuery();

                out.println("<table>");
                out.println("<tr><th>SKU</th><th>Producto</th><th>Cantidad</th><th>Precio Unitario</th><th>Acciones</th></tr>");
                while (rs.next()) {
                    String sku = rs.getString("SKU");
                    out.println("<tr>");
                    out.println("<td>" + sku + "</td>");
                    out.println("<td>" + rs.getString("descripcion") + "</td>");
                    out.println("<td>" + rs.getInt("cantidad") + "</td>");
                    out.println("<td>" + rs.getBigDecimal("precio_unitario") + "</td>");
                    out.println("<td>");
                    out.println("<a href='editarDetalleOrden?num_orden=" + numOrden + "&sku=" + sku + "' class='accion accion-editar'>Editar</a> ");
                    out.println("<a href='eliminarDetalleOrden?num_orden=" + numOrden + "&sku=" + sku + "' class='accion accion-eliminar' onclick='return confirm(\"¿Eliminar?\")'>Eliminar</a>");
                    out.println("</td>");
                    out.println("</tr>");
                }
                out.println("</table>");
            } catch (Exception e) {
                out.println("<div class='mensaje mensaje-error'>Error: " + e.getMessage() + "</div>");
            }
            out.println("<a href='ServAllOrdenesCompra' class='volver'>← Volver a órdenes</a>");
            out.println("</div>");
            out.println("<footer class='main-footer'><div>© 2026 RESPIMAS · Todos los derechos reservados</div></footer>");
            out.println("</body></html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        processRequest(req, resp);
    }
}