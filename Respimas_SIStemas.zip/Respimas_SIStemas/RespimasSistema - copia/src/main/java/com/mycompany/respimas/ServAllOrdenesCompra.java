/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.respimas;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ianac
 */
@WebServlet("/ServAllOrdenesCompra")
public class ServAllOrdenesCompra extends HttpServlet {
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
        response.setHeader("Pragma", "no-cache");
        response.setDateHeader("Expires", 0);
        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html><html><head><title>Órdenes de Compra</title>");
            out.println("<link rel='stylesheet' type='text/css' href='estilos.css'>");
            out.println("</head><body>");
            out.println("<header class='main-header'>");
            out.println("<div class='logo-area'><div class='company-text'><h2>RESPIMAS</h2></div></div>");
            out.println("<div class='user-area'>");
            out.println("<span class='user-greeting'>👋 <strong>" + request.getSession().getAttribute("nombre") + "</strong> (" + request.getSession().getAttribute("usuario") + ") | Rol: " + request.getSession().getAttribute("rol") + "</span>");
            out.println("<a href='ServLogout' class='logout-btn' onclick='return confirm(\"¿Cerrar sesión?\")'>Cerrar sesión</a>");
            out.println("</div>");
            out.println("</header>");
            out.println("<div class='container'>");
            out.println("<h2>Órdenes de Compra</h2>");
            out.println("<a href='formAltaOrdenCompra2.jsp' class='accion-agregar'>➕ Agregar orden</a>");

            try (Connection conn = ConexionBD.getConnection();
                 Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(
                     "SELECT oc.*, p.nombre FROM ORDEN_COMPRA oc " +
                     "INNER JOIN PROVEEDOR p ON oc.proveedor_RFC = p.RFC " +
                     "ORDER BY oc.fecha DESC")) {

                out.println("<table>");
                out.println("<tr><th>Núm. Orden</th><th>Fecha</th><th>Proveedor</th><th>Subtotal</th><th>IVA</th><th>Total</th><th>Estatus</th><th>Acciones</th></tr>");
                while (rs.next()) {
                    String numOrden = rs.getString("num_orden");
                    String estatus = rs.getString("estatus");
                    String claseBadge = "";
                    if ("Enviada".equals(estatus)) {
                        claseBadge = "badge badge-enviada";
                    } else if ("Recibida".equals(estatus)) {
                        claseBadge = "badge badge-recibida";
                    } else if ("Cancelada".equals(estatus)) {
                        claseBadge = "badge badge-cancelada";
                    }
                    out.println("<tr>");
                    out.println("<td>" + numOrden + "</td>");
                    out.println("<td>" + rs.getDate("fecha") + "</td>");
                    out.println("<td>" + rs.getString("nombre") + "</td>");
                    out.println("<td>" + rs.getBigDecimal("subtotal") + "</td>");
                    out.println("<td>" + rs.getBigDecimal("IVA") + "</td>");
                    out.println("<td>" + rs.getBigDecimal("total") + "</td>");
                    out.println("<td><span class='" + claseBadge + "'>" + estatus + "</span></td>");
                    out.println("<td>");
                    out.println("<a href='editarOrdenCompra?num_orden=" + numOrden + "' class='accion accion-editar'>Editar</a> ");
                    out.println("<a href='eliminarOrdenCompra?num_orden=" + numOrden + "' class='accion accion-eliminar' onclick='return confirm(\"¿Eliminar?\")'>Eliminar</a> ");
                    out.println("<a href='ServAllDetalleOrden?num_orden=" + numOrden + "' class='accion accion-detalle'>Detalles</a> ");
                    if ("Enviada".equals(estatus)) {
                        out.println("<a href='ServRecibirOrdenCompra?num_orden=" + numOrden + "' class='accion accion-detalle'>Recibir</a>");
                    }
                    out.println("</td>");
                    out.println("</tr>");
                }
                out.println("</table>");
            } catch (Exception e) {
                out.println("<div class='mensaje mensaje-error'>Error: " + e.getMessage() + "</div>");
            }
            out.println("<a href='index.jsp' class='volver'>← Volver al inicio</a>");
            out.println("</div>");
            out.println("<footer class='main-footer'><div>© 2026 RESPIMAS · Todos los derechos reservados</div></footer>");
            out.println("</body></html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException { processRequest(req, resp); }
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException { processRequest(req, resp); }
}