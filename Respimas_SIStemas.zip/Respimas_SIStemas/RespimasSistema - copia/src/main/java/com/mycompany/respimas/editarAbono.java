/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.respimas;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/**
 *
 * @author ianac
 */
@WebServlet("/editarAbono")
public class editarAbono extends HttpServlet {

    // -------------------------------------------------------
    // GET: muestra el formulario de edición con los datos actuales
    // -------------------------------------------------------
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        int id = Integer.parseInt(req.getParameter("id"));
        resp.setContentType("text/html;charset=UTF-8");
        PrintWriter out = resp.getWriter();

        out.println("<!DOCTYPE html><html><head><title>Editar Abono</title>");
        out.println("<link rel='stylesheet' type='text/css' href='estilos.css'>");
        out.println("</head><body class='page-layout'><div class='container'>");
        out.println("<h2>Editar Abono</h2>");

        try (Connection conn = ConexionBD.getConnection();
             PreparedStatement pst = conn.prepareStatement("SELECT * FROM ABONO WHERE id_abono = ?")) {
            pst.setInt(1, id);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                out.println("<form action='editarAbono' method='post'>");
                out.println("<input type='hidden' name='id' value='" + rs.getInt("id_abono") + "'>");

                out.println("<label>Fecha:</label>");
                out.println("<input type='date' name='fecha' value='" + rs.getDate("fecha") + "' required>");

                out.println("<label>Monto:</label>");
                out.println("<input type='number' step='0.01' name='monto' value='" + rs.getDouble("monto") + "' required>");

                out.println("<label>Referencia Bancaria:</label>");
                out.println("<input type='text' name='referencia_bancaria' value='" + rs.getString("referencia_bancaria") + "'>");

                out.println("<label>Saldo Restante:</label>");
                out.println("<input type='number' step='0.01' name='saldo_restante' value='" + rs.getDouble("saldo_restante") + "' required>");

                out.println("<label>Factura Folio:</label>");
                out.println("<input type='text' name='factura_folio' value='" + rs.getString("factura_folio") + "' required>");

                out.println("<br><input type='submit' value='Actualizar' class='accion-agregar'>");
                out.println("</form>");
            } else {
                out.println("<div class='mensaje mensaje-error'>Abono no encontrado.</div>");
            }
        } catch (Exception e) {
            out.println("<div class='mensaje mensaje-error'>Error: " + e.getMessage() + "</div>");
        }
        out.println("<br><a href='ServAllAbonos' class='volver'>← Cancelar</a>");
        out.println("</div></body></html>");
    }

    // -------------------------------------------------------
    // POST: actualiza el abono (lógica original sin cambios)
    // -------------------------------------------------------
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        int id = Integer.parseInt(req.getParameter("id"));
        String fecha = req.getParameter("fecha");
        double monto = Double.parseDouble(req.getParameter("monto"));
        String referenciaBancaria = req.getParameter("referencia_bancaria");
        double saldoRestante = Double.parseDouble(req.getParameter("saldo_restante"));
        String facturaFolio = req.getParameter("factura_folio");

        String sql = "UPDATE ABONO SET fecha=?, monto=?, referencia_bancaria=?, saldo_restante=?, factura_folio=? WHERE id_abono=?";
        try (Connection conn = ConexionBD.getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, fecha);
            pst.setDouble(2, monto);
            pst.setString(3, referenciaBancaria);
            pst.setDouble(4, saldoRestante);
            pst.setString(5, facturaFolio);
            pst.setInt(6, id);
            pst.executeUpdate();
            resp.sendRedirect("ServAllAbonos");
        } catch (Exception e) {
            try (PrintWriter out = resp.getWriter()) {
                out.println("<div class='mensaje mensaje-error'>Error al actualizar: " + e.getMessage() + "</div>");
            }
        }
    }
}