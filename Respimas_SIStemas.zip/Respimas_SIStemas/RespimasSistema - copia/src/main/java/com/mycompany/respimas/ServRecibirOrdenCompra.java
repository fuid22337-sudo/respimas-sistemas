/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.respimas;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ianac
 */
@WebServlet("/ServRecibirOrdenCompra")
public class ServRecibirOrdenCompra extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String numOrden = request.getParameter("num_orden");

        try (PrintWriter out = response.getWriter()) {
            if (numOrden == null || numOrden.isEmpty()) {
                out.println("<!DOCTYPE html><html><head><title>Error</title>");
                out.println("<link rel='stylesheet' type='text/css' href='estilos.css'>");
                out.println("</head><body><div class='container'>");
                out.println("<div class='mensaje mensaje-error'>Número de orden no proporcionado.</div>");
                out.println("<a href='ServAllOrdenesCompra' class='volver'>← Volver</a>");
                out.println("</div></body></html>");
                return;
            }

            Connection conn = null;
            try {
                conn = ConexionBD.getConnection();
                conn.setAutoCommit(false);

                // Verificar estado actual
                String sqlCheck = "SELECT estatus FROM ORDEN_COMPRA WHERE num_orden = ?";
                PreparedStatement pstCheck = conn.prepareStatement(sqlCheck);
                pstCheck.setString(1, numOrden);
                ResultSet rsCheck = pstCheck.executeQuery();
                if (!rsCheck.next()) {
                    throw new Exception("La orden no existe.");
                }
                String estatusActual = rsCheck.getString("estatus");
                rsCheck.close();

                if ("Recibida".equals(estatusActual)) {
                    throw new Exception("La orden ya fue recibida anteriormente.");
                }

                // Cambiar estatus a Recibida
                String sqlUpdEst = "UPDATE ORDEN_COMPRA SET estatus = 'Recibida' WHERE num_orden = ?";
                PreparedStatement pstUpdEst = conn.prepareStatement(sqlUpdEst);
                pstUpdEst.setString(1, numOrden);
                pstUpdEst.executeUpdate();

                // Obtener líneas de detalle
                String sqlDet = "SELECT SKU, cantidad FROM DETALLE_ORDEN WHERE num_orden = ?";
                PreparedStatement pstDet = conn.prepareStatement(sqlDet);
                pstDet.setString(1, numOrden);
                ResultSet rsDet = pstDet.executeQuery();

                String sqlUpdProd = "UPDATE PRODUCTO SET existencia_actual = existencia_actual + ? WHERE SKU = ?";
                String sqlMov = "INSERT INTO MOVIMIENTO_INVENTARIO (fecha, tipo, cantidad, referencia, SKU) VALUES (CURDATE(), 'entrada', ?, ?, ?)";

                PreparedStatement pstUpdProd = conn.prepareStatement(sqlUpdProd);
                PreparedStatement pstMov = conn.prepareStatement(sqlMov);

                while (rsDet.next()) {
                    String sku = rsDet.getString("SKU");
                    int cantidad = rsDet.getInt("cantidad");

                    // Actualizar existencia
                    pstUpdProd.setInt(1, cantidad);
                    pstUpdProd.setString(2, sku);
                    pstUpdProd.executeUpdate();

                    // Registrar movimiento
                    pstMov.setInt(1, cantidad);
                    pstMov.setString(2, numOrden);
                    pstMov.setString(3, sku);
                    pstMov.executeUpdate();
                }

                conn.commit();

                // Éxito
                out.println("<!DOCTYPE html><html><head><title>Orden Recibida</title>");
                out.println("<link rel='stylesheet' type='text/css' href='estilos.css'>");
                out.println("</head><body><div class='container'>");
                out.println("<div class='mensaje mensaje-exito'>Orden " + numOrden + " marcada como Recibida. Inventario actualizado.</div>");
                out.println("<a href='ServAllOrdenesCompra' class='volver'>← Volver a órdenes</a>");
                out.println("</div></body></html>");

            } catch (Exception e) {
                if (conn != null) {
                    try { conn.rollback(); } catch (Exception ex) { }
                }
                // Usamos el mismo out
                out.println("<!DOCTYPE html><html><head><title>Error</title>");
                out.println("<link rel='stylesheet' type='text/css' href='estilos.css'>");
                out.println("</head><body><div class='container'>");
                out.println("<div class='mensaje mensaje-error'>Error al recibir orden: " + e.getMessage() + "</div>");
                out.println("<a href='ServAllOrdenesCompra' class='volver'>← Volver</a>");
                out.println("</div></body></html>");
            } finally {
                if (conn != null) {
                    try { conn.setAutoCommit(true); conn.close(); } catch (Exception ex) { }
                }
            }
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        processRequest(req, resp);
    }
}