/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.respimas;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/**
 *
 * @author ianac
 */
@WebServlet("/ServAllDetalleCotizacion")
public class ServAllDetalleCotizacion extends HttpServlet {
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html><html><head><title>Detalle Cotizaciones</title>");
            out.println("<link rel='stylesheet' type='text/css' href='estilos.css'>");
            out.println("</head><body>");
            out.println("<header class='main-header'>");
            out.println("<div class='logo-area'><div class='company-text'><h2>RESPIMAS</h2></div></div>");
            out.println("<div class='user-area'>");
            out.println("<span class='user-greeting'>👋 <strong>" + request.getSession().getAttribute("nombre") + "</strong> (" + request.getSession().getAttribute("usuario") + ") | Rol: " + request.getSession().getAttribute("rol") + "</span>");
            out.println("<a href='ServLogout' class='logout-btn' onclick='return confirm(\"¿Cerrar sesión?\")'>Cerrar sesión</a>");
            out.println("</div>");
            out.println("</header>");
            out.println("<div class='container'>");
            out.println("<h2>Detalle de Cotizaciones</h2>");
            out.println("<a href='formAltaDetalleCotizacion2.jsp' class='accion-agregar'>➕ Agregar detalle</a>");

            // Consulta con JOIN para mostrar descripción del producto y calcular importe
            String sql = "SELECT dc.num_cotizacion, dc.SKU, p.descripcion, dc.cantidad, dc.precio_unitario, " +
                         "(dc.cantidad * dc.precio_unitario) AS importe " +
                         "FROM DETALLE_COTIZACION dc " +
                         "INNER JOIN PRODUCTO p ON dc.SKU = p.SKU " +
                         "ORDER BY dc.num_cotizacion, dc.SKU";

            try (Connection conn = ConexionBD.getConnection();
                 Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(sql)) {

                out.println("<table>");
                out.println("<tr><th>Núm. Cotización</th><th>SKU</th><th>Producto</th><th>Cantidad</th><th>Precio Unitario</th><th>Importe</th><th>Acciones</th></tr>");
                while (rs.next()) {
                    String num = rs.getString("num_cotizacion");
                    String sku = rs.getString("SKU");
                    out.println("<tr>");
                    out.println("<td>" + num + "</td>");
                    out.println("<td>" + sku + "</td>");
                    out.println("<td>" + rs.getString("descripcion") + "</td>");
                    out.println("<td>" + rs.getInt("cantidad") + "</td>");
                    out.println("<td>" + rs.getBigDecimal("precio_unitario") + "</td>");
                    out.println("<td>" + rs.getBigDecimal("importe") + "</td>");
                    out.println("<td>");
                    out.println("<a href='editarDetalleCotizacion?num_cotizacion=" + num + "&sku=" + sku + "' class='accion accion-editar'>Editar</a> ");
                    out.println("<a href='eliminarDetalleCotizacion?num_cotizacion=" + num + "&sku=" + sku + "' class='accion accion-eliminar' onclick='return confirm(\"¿Eliminar?\")'>Eliminar</a>");
                    out.println("</td>");
                    out.println("</tr>");
                }
                out.println("</table>");
            } catch (Exception e) {
                out.println("<div class='mensaje mensaje-error'>Error: " + e.getMessage() + "</div>");
            }
            out.println("<a href='index.jsp' class='volver'>← Volver al inicio</a>");
            out.println("</div>");
            out.println("<footer class='main-footer'><div>© 2026 RESPIMAS · Todos los derechos reservados</div></footer>");
            out.println("</body></html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        processRequest(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        processRequest(req, resp);
    }
}