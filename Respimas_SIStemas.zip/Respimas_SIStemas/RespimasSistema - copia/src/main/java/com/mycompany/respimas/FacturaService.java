/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.respimas;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


/**
 *
 * @author ianac
 */
public class FacturaService {

    /**
     * Recalcula el saldo pendiente y actualiza el estatus de la factura
     * basado en la suma de sus abonos.
     * @param conn Conexión activa (debe estar en transacción si se usa con otros cambios)
     * @param folioFactura Folio de la factura
     * @throws SQLException
     */
    public static void actualizarSaldoYEstatusFactura(Connection conn, String folioFactura) throws SQLException {
        // 1. Calcular total abonado
        double totalAbonado = 0;
        String sqlSum = "SELECT COALESCE(SUM(monto), 0) FROM ABONO WHERE factura_folio = ?";
        try (PreparedStatement pst = conn.prepareStatement(sqlSum)) {
            pst.setString(1, folioFactura);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) totalAbonado = rs.getDouble(1);
        }
        
        // 2. Obtener monto total de la factura
        double montoTotal = 0;
        String sqlFact = "SELECT monto_total FROM FACTURA_VENTA WHERE folio = ?";
        try (PreparedStatement pst = conn.prepareStatement(sqlFact)) {
            pst.setString(1, folioFactura);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) montoTotal = rs.getDouble(1);
        }
        
        double saldo = montoTotal - totalAbonado;
        String nuevoEstatus;
        if (saldo <= 0.01) { // tolerancia por decimales
            nuevoEstatus = "Pagada";
        } else if (totalAbonado > 0) {
            nuevoEstatus = "Pago parcial";
        } else {
            nuevoEstatus = "Pendiente";
        }
        
        // 3. Actualizar estatus y opcionalmente un campo saldo_actual (si existiera)
        String sqlUpdate = "UPDATE FACTURA_VENTA SET estatus = ? WHERE folio = ?";
        try (PreparedStatement pst = conn.prepareStatement(sqlUpdate)) {
            pst.setString(1, nuevoEstatus);
            pst.setString(2, folioFactura);
            pst.executeUpdate();
        }
    }
}
