/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.respimas;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ianac
 */
@WebServlet("/ServInsProveedor")
public class ServInsProveedor extends HttpServlet {
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String rfc = request.getParameter("rfc");
            String nombre = request.getParameter("nombre");
            String condicionesPago = request.getParameter("condiciones_pago");
            String contacto = request.getParameter("contacto");
            String datosBancarios = request.getParameter("datos_bancarios");

            String sql = "INSERT INTO PROVEEDOR (RFC, nombre, condiciones_pago, contacto, datos_bancarios) VALUES (?,?,?,?,?)";
            try (Connection conn = ConexionBD.getConnection();
                 PreparedStatement pst = conn.prepareStatement(sql)) {
                pst.setString(1, rfc);
                pst.setString(2, nombre);
                pst.setString(3, condicionesPago);
                pst.setString(4, contacto);
                pst.setString(5, datosBancarios);
                int filas = pst.executeUpdate();
                if (filas > 0) {
                    out.println("<h3>Proveedor registrado exitosamente</h3>");
                    out.println("<a href='ServAllProveedores'>Volver a proveedores</a>");
                } else {
                    out.println("<h3>Error al registrar proveedor</h3>");
                }
            } catch (Exception e) {
                out.println("<p>Error: " + e.getMessage() + "</p>");
            }
        }
    }
    @Override protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException { processRequest(req, resp); }
}
