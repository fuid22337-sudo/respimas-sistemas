/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.respimas;

import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

/**
 *
 * @author ianac
 */
@WebServlet("/ServAllUsuarios")
public class ServAllUsuarios extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
        response.setHeader("Pragma", "no-cache");
        response.setDateHeader("Expires", 0);

        // Solo administrador
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("logueado") == null) {
            response.sendRedirect("login.jsp");
            return;
        }
        String rol = (String) session.getAttribute("rol");
        if (!"admin".equals(rol)) {
            response.sendRedirect("index.jsp");
            return;
        }

        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html><html><head><title>Usuarios - RESPIMAS</title>");
            out.println("<link rel='stylesheet' type='text/css' href='estilos.css'>");
            out.println("</head><body>");
            out.println("<div class='container'>");
            out.println("<h2>Administración de Usuarios</h2>");
            out.println("<a href='formAltaUsuario.jsp' class='accion-agregar'>➕ Nuevo usuario</a>");

            try (Connection conn = ConexionBD.getConnection();
                 Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery("SELECT id, username, nombre, rol FROM usuarios ORDER BY username")) {

                out.println("<table>");
                out.println("<tr><th>ID</th><th>Usuario</th><th>Nombre Completo</th><th>Rol</th><th>Acciones</th></tr>");
                while (rs.next()) {
                    int id = rs.getInt("id");
                    String username = rs.getString("username");
                    String nombre = rs.getString("nombre");
                    String rolUser = rs.getString("rol");
                    out.println("<tr>");
                    out.println("<td>" + id + "</td>");
                    out.println("<td>" + username + "</td>");
                    out.println("<td>" + (nombre != null ? nombre : "") + "</td>");
                    out.println("<td>" + rolUser + "</td>");
                    out.println("<td>");
                    // No permitir eliminar al propio admin que está logueado
                    String sesionUsername = (String) session.getAttribute("usuario");
                    if (!username.equals(sesionUsername)) {
                        out.println("<a href='editarUsuario?id=" + id + "' class='accion accion-editar'>Editar</a> ");
                        out.println("<a href='eliminarUsuario?id=" + id + "' class='accion accion-eliminar' onclick='return confirm(\"¿Eliminar usuario?\")'>Eliminar</a>");
                    } else {
                        out.println("<em>Usuario actual</em>");
                    }
                    out.println("</td>");
                    out.println("</tr>");
                }
                out.println("</table>");
            } catch (Exception e) {
                out.println("<div class='mensaje mensaje-error'>Error: " + e.getMessage() + "</div>");
            }
            out.println("<a href='index.jsp' class='volver'>← Volver al panel</a>");
            out.println("</div></body></html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        processRequest(req, resp);
    }
}