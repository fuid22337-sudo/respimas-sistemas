/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.respimas;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ianac
 */
@WebServlet("/ServAllFacturasCompra")
public class ServAllFacturasCompra extends HttpServlet {
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
        response.setHeader("Pragma", "no-cache");
        response.setDateHeader("Expires", 0);
        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html><html><head><title>Facturas de Compra</title>");
            out.println("<link rel='stylesheet' type='text/css' href='estilos.css'>");
            out.println("</head><body>");
            out.println("<header class='main-header'>");
            out.println("<div class='logo-area'><div class='company-text'><h2>RESPIMAS</h2></div></div>");
            out.println("<div class='user-area'>");
            out.println("<span class='user-greeting'>👋 <strong>" + request.getSession().getAttribute("nombre") + "</strong> (" + request.getSession().getAttribute("usuario") + ") | Rol: " + request.getSession().getAttribute("rol") + "</span>");
            out.println("<a href='ServLogout' class='logout-btn' onclick='return confirm(\"¿Cerrar sesión?\")'>Cerrar sesión</a>");
            out.println("</div>");
            out.println("</header>");
            out.println("<div class='container'>");
            out.println("<h2>Facturas de Compra</h2>");
            out.println("<a href='formAltaFacturaCompra2.jsp' class='accion-agregar'>➕ Nueva factura de compra</a>");

            try (Connection conn = ConexionBD.getConnection();
                 Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery("SELECT * FROM FACTURA_COMPRA ORDER BY fecha DESC")) {

                out.println("<table>");
                out.println("<tr><th>Folio Proveedor</th><th>Fecha</th><th>Monto Total</th><th>IVA</th><th>Fecha Vencimiento</th><th>Fecha Pago</th><th>Estatus</th><th>Núm. Orden</th><th>Acciones</th></tr>");
                while (rs.next()) {
                    String folio = rs.getString("folio_proveedor");
                    String estatus = rs.getString("estatus");
                    String claseBadge = "";
                    if ("Pendiente".equals(estatus)) {
                        claseBadge = "badge badge-pendiente";
                    } else if ("Pagada".equals(estatus)) {
                        claseBadge = "badge badge-pagada";
                    } else if ("Cancelada".equals(estatus)) {
                        claseBadge = "badge badge-cancelada";
                    }
                    out.println("<tr>");
                    out.println("<td>" + folio + "</td>");
                    out.println("<td>" + rs.getDate("fecha") + "</td>");
                    out.println("<td>" + rs.getBigDecimal("monto_total") + "</td>");
                    out.println("<td>" + rs.getBigDecimal("IVA") + "</td>");
                    out.println("<td>" + rs.getDate("fecha_vencimiento") + "</td>");
                    out.println("<td>" + rs.getDate("fecha_pago") + "</td>");
                    out.println("<td><span class='" + claseBadge + "'>" + estatus + "</span></td>");
                    out.println("<td>" + rs.getString("num_orden") + "</td>");
                    out.println("<td>");
                    out.println("<a href='editorFacturaCompra?folio_proveedor=" + folio + "' class='accion accion-editar'>Editar</a> ");
                    out.println("<a href='eliminarFacturaCompra?folio_proveedor=" + folio + "' class='accion accion-eliminar' onclick='return confirm(\"¿Eliminar?\")'>Eliminar</a>");
                    out.println("</td>");
                    out.println("</tr>");
                }
                out.println("</table>");
            } catch (Exception e) {
                out.println("<div class='mensaje mensaje-error'>Error: " + e.getMessage() + "</div>");
            }
            out.println("<a href='index.jsp' class='volver'>← Volver al inicio</a>");
            out.println("</div>");
            out.println("<footer class='main-footer'><div>© 2026 RESPIMAS · Todos los derechos reservados</div></footer>");
            out.println("</body></html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException { processRequest(req, resp); }
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException { processRequest(req, resp); }
}