/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.respimas;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ianac
 */@WebServlet("/editarCliente")
public class editarCliente extends HttpServlet {

    // -------------------------------------------------------
    // GET: muestra el formulario de edición con los datos actuales
    // -------------------------------------------------------
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String rfc = req.getParameter("rfc");
        resp.setContentType("text/html;charset=UTF-8");
        PrintWriter out = resp.getWriter();

        out.println("<!DOCTYPE html><html><head><title>Editar Cliente</title>");
        out.println("<link rel='stylesheet' type='text/css' href='estilos.css'>");
        out.println("</head><body class='page-layout'><div class='container'>");
        out.println("<h2>Editar Cliente</h2>");

        try (Connection conn = ConexionBD.getConnection();
             PreparedStatement pst = conn.prepareStatement("SELECT * FROM CLIENTE WHERE RFC = ?")) {
            pst.setString(1, rfc);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                out.println("<form action='editarCliente' method='post'>");
                out.println("<input type='hidden' name='rfc' value='" + rs.getString("RFC") + "'>");

                out.println("<label>RFC:</label>");
                out.println("<input type='text' value='" + rs.getString("RFC") + "' disabled>");

                out.println("<label>Nombre Comercial:</label>");
                out.println("<input type='text' name='nombre_comercial' value='" + rs.getString("nombre_comercial") + "' required>");

                out.println("<label>Razón Social:</label>");
                out.println("<input type='text' name='razon_social' value='" + rs.getString("razon_social") + "'>");

                out.println("<label>Dirección:</label>");
                out.println("<input type='text' name='direccion' value='" + rs.getString("direccion") + "'>");

                out.println("<label>Teléfono:</label>");
                out.println("<input type='text' name='telefono' value='" + rs.getString("telefono") + "'>");

                out.println("<label>Contacto:</label>");
                out.println("<input type='text' name='contacto' value='" + rs.getString("contacto") + "'>");

                out.println("<label>Límite Crédito:</label>");
                out.println("<input type='number' step='0.01' name='limite_credito' value='" + rs.getDouble("limite_credito") + "' required>");

                out.println("<br><input type='submit' value='Actualizar' class='accion-agregar'>");
                out.println("</form>");
            } else {
                out.println("<div class='mensaje mensaje-error'>Cliente no encontrado.</div>");
            }
        } catch (Exception e) {
            out.println("<div class='mensaje mensaje-error'>Error: " + e.getMessage() + "</div>");
        }
        out.println("<br><a href='ServAllClientes' class='volver'>← Cancelar</a>");
        out.println("</div></body></html>");
    }

    // -------------------------------------------------------
    // POST: actualiza los datos del cliente
    // -------------------------------------------------------
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String rfc = req.getParameter("rfc");
        String nombreComercial = req.getParameter("nombre_comercial");
        String razonSocial = req.getParameter("razon_social");
        String direccion = req.getParameter("direccion");
        String telefono = req.getParameter("telefono");
        String contacto = req.getParameter("contacto");
        double limiteCredito = Double.parseDouble(req.getParameter("limite_credito"));

        String sql = "UPDATE CLIENTE SET nombre_comercial=?, razon_social=?, direccion=?, telefono=?, contacto=?, limite_credito=? WHERE RFC=?";
        try (Connection conn = ConexionBD.getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, nombreComercial);
            pst.setString(2, razonSocial);
            pst.setString(3, direccion);
            pst.setString(4, telefono);
            pst.setString(5, contacto);
            pst.setDouble(6, limiteCredito);
            pst.setString(7, rfc);
            int filas = pst.executeUpdate();
            if (filas > 0) {
                resp.sendRedirect("ServAllClientes");
            } else {
                try (PrintWriter out = resp.getWriter()) {
                    out.println("<div class='mensaje mensaje-error'>Error al actualizar.</div>");
                }
            }
        } catch (Exception e) {
            try (PrintWriter out = resp.getWriter()) {
                out.println("<div class='mensaje mensaje-error'>Error: " + e.getMessage() + "</div>");
            }
        }
    }
}