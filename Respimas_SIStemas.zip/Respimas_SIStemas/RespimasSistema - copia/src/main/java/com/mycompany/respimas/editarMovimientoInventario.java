/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.respimas;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Date;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ianac
 */
@WebServlet("/editarMovimientoInventario")
public class editarMovimientoInventario extends HttpServlet {

    // Mostrar formulario de edición (GET)
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int id = Integer.parseInt(req.getParameter("id"));
        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();
        out.println("<html><head><title>Editar Movimiento</title>");
        out.println("<style>input,select{width:100%;padding:5px;margin:5px 0;}</style>");
        out.println("</head><body>");
        out.println("<h2>Editar Movimiento de Inventario</h2>");

        try (Connection conn = ConexionBD.getConnection();
             PreparedStatement pst = conn.prepareStatement("SELECT * FROM MOVIMIENTO_INVENTARIO WHERE id_mov = ?")) {
            pst.setInt(1, id);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                out.println("<form action='editarMovimientoInventario' method='POST'>");
                out.println("<input type='hidden' name='id' value='" + id + "'>");
                out.println("Fecha: <input type='date' name='fecha' value='" + rs.getDate("fecha") + "' required><br>");
                out.println("Tipo: <select name='tipo'>");
                out.println("<option value='entrada'" + ("entrada".equals(rs.getString("tipo")) ? "selected" : "") + ">Entrada</option>");
                out.println("<option value='salida'" + ("salida".equals(rs.getString("tipo")) ? "selected" : "") + ">Salida</option>");
                out.println("</select><br>");
                out.println("Cantidad: <input type='number' name='cantidad' value='" + rs.getInt("cantidad") + "' required><br>");
                out.println("Referencia: <input type='text' name='referencia' value='" + (rs.getString("referencia") != null ? rs.getString("referencia") : "") + "'><br>");
                out.println("SKU: <input type='text' name='sku' value='" + rs.getString("SKU") + "' required><br>");
                out.println("<input type='submit' value='Actualizar'>");
                out.println("</form>");
            } else {
                out.println("<p>Movimiento no encontrado</p>");
            }
        } catch (Exception e) {
            out.println("<p>Error: " + e.getMessage() + "</p>");
        }
        out.println("<br><a href='ServAllMovimientosInventario'>Cancelar</a>");
        out.println("</body></html>");
    }

    // Procesar actualización (POST)
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int id = Integer.parseInt(req.getParameter("id"));
        Date fecha = Date.valueOf(req.getParameter("fecha"));
        String tipo = req.getParameter("tipo");
        int cantidad = Integer.parseInt(req.getParameter("cantidad"));
        String referencia = req.getParameter("referencia");
        String sku = req.getParameter("sku");

        String sql = "UPDATE MOVIMIENTO_INVENTARIO SET fecha=?, tipo=?, cantidad=?, referencia=?, SKU=? WHERE id_mov=?";

        try (Connection conn = ConexionBD.getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setDate(1, fecha);
            pst.setString(2, tipo);
            pst.setInt(3, cantidad);
            pst.setString(4, referencia);
            pst.setString(5, sku);
            pst.setInt(6, id);

            pst.executeUpdate();
            resp.sendRedirect("ServAllMovimientosInventario");
        } catch (Exception e) {
            resp.getWriter().println("Error al actualizar: " + e.getMessage());
        }
    }
}