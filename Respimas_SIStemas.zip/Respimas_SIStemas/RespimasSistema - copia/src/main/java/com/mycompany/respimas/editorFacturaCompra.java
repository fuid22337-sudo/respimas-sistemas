/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.respimas;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Date;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ianac
 */
@WebServlet("/editorFacturaCompra")
public class editorFacturaCompra extends HttpServlet {

    // -------------------------------------------------------
    // GET: muestra el formulario de edición con los datos actuales
    // -------------------------------------------------------
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String folioProveedor = req.getParameter("folio_proveedor");
        resp.setContentType("text/html;charset=UTF-8");
        PrintWriter out = resp.getWriter();

        out.println("<!DOCTYPE html><html><head><title>Editar Factura de Compra</title>");
        out.println("<link rel='stylesheet' type='text/css' href='estilos.css'>");
        out.println("</head><body><div class='container'>");
        out.println("<h2>Editar Factura de Compra</h2>");

        try (Connection conn = ConexionBD.getConnection();
             PreparedStatement pst = conn.prepareStatement("SELECT * FROM FACTURA_COMPRA WHERE folio_proveedor = ?")) {
            pst.setString(1, folioProveedor);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                String numOrdenActual = rs.getString("num_orden");

                out.println("<form action='editorFacturaCompra' method='post'>");
                out.println("<input type='hidden' name='folio_proveedor' value='" + rs.getString("folio_proveedor") + "'>");

                out.println("<label>Fecha:</label>");
                out.println("<input type='date' name='fecha' value='" + rs.getDate("fecha") + "' required>");

                out.println("<label>Monto Total:</label>");
                out.println("<input type='number' step='0.01' name='monto_total' value='" + rs.getBigDecimal("monto_total") + "' required>");

                out.println("<label>IVA:</label>");
                out.println("<input type='number' step='0.01' name='iva' value='" + rs.getBigDecimal("IVA") + "'>");

                out.println("<label>Fecha Vencimiento:</label>");
                out.println("<input type='date' name='fecha_vencimiento' value='" + rs.getDate("fecha_vencimiento") + "' required>");

                out.println("<label>Fecha Pago:</label>");
                out.println("<input type='date' name='fecha_pago' value='" + (rs.getDate("fecha_pago") != null ? rs.getDate("fecha_pago") : "") + "'>");

                out.println("<label>Estatus:</label>");
                out.println("<select name='estatus'>");
                out.println("<option value='Pendiente'" + ("Pendiente".equals(rs.getString("estatus")) ? "selected" : "") + ">Pendiente</option>");
                out.println("<option value='Pagada'" + ("Pagada".equals(rs.getString("estatus")) ? "selected" : "") + ">Pagada</option>");
                out.println("<option value='Cancelada'" + ("Cancelada".equals(rs.getString("estatus")) ? "selected" : "") + ">Cancelada</option>");
                out.println("</select>");

                out.println("<label>Orden de Compra asociada:</label>");
                out.println("<select name='num_orden'>");
                out.println("<option value=''>-- Sin orden --</option>");
                // Cargar órdenes pendientes + la orden actual (si ya estaba asociada)
                try (Statement stmt = conn.createStatement();
                     ResultSet rsOrd = stmt.executeQuery(
                         "SELECT o.num_orden, o.total, p.nombre FROM ORDEN_COMPRA o " +
                         "INNER JOIN PROVEEDOR p ON o.proveedor_RFC = p.RFC " +
                         "WHERE o.estatus = 'Enviada' OR o.num_orden = '" + (numOrdenActual != null ? numOrdenActual : "") + "' " +
                         "ORDER BY o.fecha DESC")) {
                    while (rsOrd.next()) {
                        String selected = rsOrd.getString("num_orden").equals(numOrdenActual) ? "selected" : "";
                        out.println("<option value='" + rsOrd.getString("num_orden") + "' " + selected + ">" +
                                    rsOrd.getString("num_orden") + " - " + rsOrd.getString("nombre") +
                                    " (Total: " + rsOrd.getDouble("total") + ")</option>");
                    }
                }
                out.println("</select>");

                out.println("<br><input type='submit' value='Actualizar' class='accion-agregar'>");
                out.println("</form>");
            } else {
                out.println("<div class='mensaje mensaje-error'>Factura de compra no encontrada.</div>");
            }
        } catch (Exception e) {
            out.println("<div class='mensaje mensaje-error'>Error: " + e.getMessage() + "</div>");
        }
        out.println("<br><a href='ServAllFacturasCompra' class='volver'>← Cancelar</a>");
        out.println("</div></body></html>");
    }

    // -------------------------------------------------------
    // POST: actualiza la factura y, si se asigna una nueva orden Enviada, la recibe
    // -------------------------------------------------------
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String folioProveedor = req.getParameter("folio_proveedor");
        Date fecha = Date.valueOf(req.getParameter("fecha"));
        double montoTotal = Double.parseDouble(req.getParameter("monto_total"));
        Double iva = req.getParameter("iva") != null && !req.getParameter("iva").isEmpty() ? Double.parseDouble(req.getParameter("iva")) : null;
        Date fechaVencimiento = Date.valueOf(req.getParameter("fecha_vencimiento"));
        Date fechaPago = req.getParameter("fecha_pago") != null && !req.getParameter("fecha_pago").isEmpty() ? Date.valueOf(req.getParameter("fecha_pago")) : null;
        String estatus = req.getParameter("estatus");
        String numOrdenNueva = req.getParameter("num_orden");
        if (numOrdenNueva != null && numOrdenNueva.isEmpty()) numOrdenNueva = null;

        Connection conn = null;
        try {
            conn = ConexionBD.getConnection();
            conn.setAutoCommit(false);

            // Obtener la orden antigua (antes de actualizar)
            String oldNumOrden = null;
            PreparedStatement pstOld = conn.prepareStatement("SELECT num_orden FROM FACTURA_COMPRA WHERE folio_proveedor = ?");
            pstOld.setString(1, folioProveedor);
            ResultSet rsOld = pstOld.executeQuery();
            if (rsOld.next()) {
                oldNumOrden = rsOld.getString("num_orden");
            }
            rsOld.close();
            pstOld.close();

            // Actualizar la factura de compra
            String sqlUpd = "UPDATE FACTURA_COMPRA SET fecha=?, monto_total=?, IVA=?, fecha_vencimiento=?, fecha_pago=?, estatus=?, num_orden=? WHERE folio_proveedor=?";
            PreparedStatement pstUpd = conn.prepareStatement(sqlUpd);
            pstUpd.setDate(1, fecha);
            pstUpd.setDouble(2, montoTotal);
            pstUpd.setObject(3, iva);
            pstUpd.setDate(4, fechaVencimiento);
            pstUpd.setDate(5, fechaPago);
            pstUpd.setString(6, estatus);
            pstUpd.setString(7, numOrdenNueva);
            pstUpd.setString(8, folioProveedor);
            pstUpd.executeUpdate();

            // Si se está asignando una orden nueva que está "Enviada", recibirla automáticamente
            if (numOrdenNueva != null) {
                // Verificar el estatus de la nueva orden
                PreparedStatement pstCheck = conn.prepareStatement("SELECT estatus FROM ORDEN_COMPRA WHERE num_orden = ?");
                pstCheck.setString(1, numOrdenNueva);
                ResultSet rsCheck = pstCheck.executeQuery();
                if (rsCheck.next()) {
                    String estatusOrden = rsCheck.getString("estatus");
                    if ("Enviada".equals(estatusOrden)) {
                        // Cambiar estatus a Recibida
                        PreparedStatement pstUpdEst = conn.prepareStatement("UPDATE ORDEN_COMPRA SET estatus = 'Recibida' WHERE num_orden = ?");
                        pstUpdEst.setString(1, numOrdenNueva);
                        pstUpdEst.executeUpdate();

                        // Hacer entrada de inventario
                        PreparedStatement pstDet = conn.prepareStatement("SELECT SKU, cantidad FROM DETALLE_ORDEN WHERE num_orden = ?");
                        pstDet.setString(1, numOrdenNueva);
                        ResultSet rsDet = pstDet.executeQuery();

                        String sqlProd = "UPDATE PRODUCTO SET existencia_actual = existencia_actual + ? WHERE SKU = ?";
                        String sqlMov = "INSERT INTO MOVIMIENTO_INVENTARIO (fecha, tipo, cantidad, referencia, SKU) VALUES (CURDATE(), 'entrada', ?, ?, ?)";
                        PreparedStatement pstProd = conn.prepareStatement(sqlProd);
                        PreparedStatement pstMov = conn.prepareStatement(sqlMov);

                        while (rsDet.next()) {
                            String sku = rsDet.getString("SKU");
                            int cantidad = rsDet.getInt("cantidad");

                            pstProd.setInt(1, cantidad);
                            pstProd.setString(2, sku);
                            pstProd.executeUpdate();

                            pstMov.setInt(1, cantidad);
                            pstMov.setString(2, numOrdenNueva);
                            pstMov.setString(3, sku);
                            pstMov.executeUpdate();
                        }
                        rsDet.close();
                    }
                } else {
                    throw new Exception("La orden " + numOrdenNueva + " no existe.");
                }
                rsCheck.close();
            }

            conn.commit();
            resp.sendRedirect("ServAllFacturasCompra");
        } catch (Exception e) {
            if (conn != null) {
                try { conn.rollback(); } catch (Exception ex) {}
            }
            try (PrintWriter out = resp.getWriter()) {
                out.println("<div class='mensaje mensaje-error'>Error al actualizar: " + e.getMessage() + "</div>");
                out.println("<a href='ServAllFacturasCompra'>Volver</a>");
            } catch (IOException ex) {}
        } finally {
            if (conn != null) {
                try { conn.setAutoCommit(true); conn.close(); } catch (Exception ex) {}
            }
        }
    }
}
