/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.respimas;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;;

/**
 *
 * @author ianac
 */

@WebServlet("/ServInsAbono")
public class ServInsAbono extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String fecha = request.getParameter("fecha");
            double monto = Double.parseDouble(request.getParameter("monto"));
            String referenciaBancaria = request.getParameter("referencia_bancaria");
            String facturaFolio = request.getParameter("factura_folio");

            // --- Cálculo automático del saldo restante ---
            double saldoRestante = 0;
            Connection connAux = null;
            try {
                connAux = ConexionBD.getConnection();
                // Obtener monto total de la factura
                String sqlTotal = "SELECT monto_total FROM FACTURA_VENTA WHERE folio = ?";
                PreparedStatement pstTotal = connAux.prepareStatement(sqlTotal);
                pstTotal.setString(1, facturaFolio);
                ResultSet rsTotal = pstTotal.executeQuery();
                double montoFactura = 0;
                if (rsTotal.next()) {
                    montoFactura = rsTotal.getDouble("monto_total");
                } else {
                    throw new Exception("No se encontró la factura " + facturaFolio);
                }
                rsTotal.close();
                pstTotal.close();

                // Sumar abonos anteriores (sin contar el que se va a insertar)
                String sqlSum = "SELECT COALESCE(SUM(monto), 0) AS total_abonado FROM ABONO WHERE factura_folio = ?";
                PreparedStatement pstSum = connAux.prepareStatement(sqlSum);
                pstSum.setString(1, facturaFolio);
                ResultSet rsSum = pstSum.executeQuery();
                double totalAbonadoAnterior = 0;
                if (rsSum.next()) {
                    totalAbonadoAnterior = rsSum.getDouble("total_abonado");
                }
                rsSum.close();
                pstSum.close();

                // Saldo restante después de aplicar este abono
                saldoRestante = montoFactura - totalAbonadoAnterior - monto;
                if (saldoRestante < 0) saldoRestante = 0;
            } catch (Exception e) {
                out.println("<div class='mensaje mensaje-error'>Error al calcular saldo: " + e.getMessage() + "</div>");
                out.println("<a href='formAltaAbono2.jsp' class='volver'>← Volver al formulario</a>");
                return;
            } finally {
                if (connAux != null) try { connAux.close(); } catch (Exception ex) {}
            }

            // --- Inserción y cierre automático ---
            Connection conn = null;
            try {
                conn = ConexionBD.getConnection();
                conn.setAutoCommit(false);

                // 1. Insertar el abono
                String sqlIns = "INSERT INTO ABONO (fecha, monto, referencia_bancaria, saldo_restante, factura_folio) VALUES (?,?,?,?,?)";
                try (PreparedStatement pst = conn.prepareStatement(sqlIns)) {
                    pst.setString(1, fecha);
                    pst.setDouble(2, monto);
                    pst.setString(3, referenciaBancaria);
                    pst.setDouble(4, saldoRestante);
                    pst.setString(5, facturaFolio);
                    pst.executeUpdate();
                }

                // 2. Calcular la suma total de abonos después de esta inserción
                String sqlSumTotal = "SELECT COALESCE(SUM(monto), 0) AS total_abonado FROM ABONO WHERE factura_folio = ?";
                double totalAbonado = 0;
                try (PreparedStatement pstSumT = conn.prepareStatement(sqlSumTotal)) {
                    pstSumT.setString(1, facturaFolio);
                    ResultSet rsSumT = pstSumT.executeQuery();
                    if (rsSumT.next()) {
                        totalAbonado = rsSumT.getDouble("total_abonado");
                    }
                    rsSumT.close();
                }

                // 3. Obtener monto total de la factura
                String sqlMonto = "SELECT monto_total FROM FACTURA_VENTA WHERE folio = ?";
                double montoFactura = 0;
                try (PreparedStatement pstMonto = conn.prepareStatement(sqlMonto)) {
                    pstMonto.setString(1, facturaFolio);
                    ResultSet rsMonto = pstMonto.executeQuery();
                    if (rsMonto.next()) {
                        montoFactura = rsMonto.getDouble("monto_total");
                    }
                    rsMonto.close();
                }

                // 4. Si el total abonado >= monto de la factura, cerrarla
                if (totalAbonado >= montoFactura) {
                    String sqlCerrar = "UPDATE FACTURA_VENTA SET estatus = 'Pagada', fecha_pago = ? WHERE folio = ?";
                    try (PreparedStatement pstCerrar = conn.prepareStatement(sqlCerrar)) {
                        pstCerrar.setString(1, fecha);
                        pstCerrar.setString(2, facturaFolio);
                        pstCerrar.executeUpdate();
                    }
                }

                conn.commit();

                // Éxito
                out.println("<!DOCTYPE html><html><head><title>Abono Registrado</title>");
                out.println("<link rel='stylesheet' type='text/css' href='estilos.css'>");
                out.println("</head><body><div class='container'>");
                out.println("<div class='mensaje mensaje-exito'>Abono registrado exitosamente.</div>");
                if (totalAbonado >= montoFactura) {
                    out.println("<p>La factura <strong>" + facturaFolio + "</strong> ha quedado saldada (Pagada).</p>");
                }
                out.println("<a href='ServAllAbonos' class='volver'>← Volver a abonos</a>");
                out.println("</div></body></html>");

            } catch (Exception e) {
                if (conn != null) {
                    try { conn.rollback(); } catch (Exception ex) {}
                }
                out.println("<!DOCTYPE html><html><head><title>Error</title>");
                out.println("<link rel='stylesheet' type='text/css' href='estilos.css'>");
                out.println("</head><body><div class='container'>");
                out.println("<div class='mensaje mensaje-error'>Error al registrar abono: " + e.getMessage() + "</div>");
                out.println("<a href='formAltaAbono2.jsp' class='volver'>← Volver al formulario</a>");
                out.println("</div></body></html>");
            } finally {
                if (conn != null) {
                    try { conn.setAutoCommit(true); conn.close(); } catch (Exception ex) {}
                }
            }
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        processRequest(req, resp);
    }
}