/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.respimas;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ianac
 */
@WebServlet("/eliminarFacturaVenta")
public class eliminarFacturaVenta extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String folio = request.getParameter("folio");

        // Abrimos el PrintWriter una sola vez para toda la respuesta
        try (PrintWriter out = response.getWriter()) {
            // Validación inicial
            if (folio == null || folio.isEmpty()) {
                out.println("<!DOCTYPE html><html><head><title>Error</title>");
                out.println("<link rel='stylesheet' type='text/css' href='estilos.css'>");
                out.println("</head><body><div class='container'>");
                out.println("<div class='mensaje mensaje-error'>Folio no proporcionado.</div>");
                out.println("<a href='ServAllFacturasVenta' class='volver'>← Volver</a>");
                out.println("</div></body></html>");
                return;
            }

            Connection conn = null;
            try {
                conn = ConexionBD.getConnection();
                conn.setAutoCommit(false);

                // 1. Obtener los movimientos de salida de esta factura
                String sqlMovs = "SELECT SKU, cantidad FROM MOVIMIENTO_INVENTARIO WHERE referencia = ? AND tipo = 'salida'";
                PreparedStatement pstMovs = conn.prepareStatement(sqlMovs);
                pstMovs.setString(1, folio);
                ResultSet rs = pstMovs.executeQuery();

                // 2. Devolver cada cantidad al inventario
                String sqlUpd = "UPDATE PRODUCTO SET existencia_actual = existencia_actual + ? WHERE SKU = ?";
                PreparedStatement pstUpd = conn.prepareStatement(sqlUpd);
                while (rs.next()) {
                    pstUpd.setInt(1, rs.getInt("cantidad"));
                    pstUpd.setString(2, rs.getString("SKU"));
                    pstUpd.executeUpdate();
                }
                rs.close();

                // 3. Eliminar los movimientos de inventario de esta factura
                String sqlDelMov = "DELETE FROM MOVIMIENTO_INVENTARIO WHERE referencia = ? AND tipo = 'salida'";
                PreparedStatement pstDelMov = conn.prepareStatement(sqlDelMov);
                pstDelMov.setString(1, folio);
                pstDelMov.executeUpdate();

                // 4. Eliminar la factura (los abonos se eliminan en cascada)
                String sqlDelFact = "DELETE FROM FACTURA_VENTA WHERE folio = ?";
                PreparedStatement pstDelFact = conn.prepareStatement(sqlDelFact);
                pstDelFact.setString(1, folio);
                int filas = pstDelFact.executeUpdate();

                if (filas == 0) {
                    throw new Exception("No se encontró la factura " + folio);
                }

                conn.commit();

                // Éxito
                out.println("<!DOCTYPE html><html><head><title>Factura Eliminada</title>");
                out.println("<link rel='stylesheet' type='text/css' href='estilos.css'>");
                out.println("</head><body><div class='container'>");
                out.println("<div class='mensaje mensaje-exito'>Factura " + folio + " eliminada correctamente. El inventario ha sido restaurado.</div>");
                out.println("<a href='ServAllFacturasVenta' class='volver'>← Volver a facturas</a>");
                out.println("</div></body></html>");

            } catch (Exception e) {
              
                if (conn != null) {
                    try { conn.rollback(); } catch (Exception ex) { }
                }
                // Usamos el mismo out para el mensaje de error
                out.println("<!DOCTYPE html><html><head><title>Error</title>");
                out.println("<link rel='stylesheet' type='text/css' href='estilos.css'>");
                out.println("</head><body><div class='container'>");
                out.println("<div class='mensaje mensaje-error'>Error al eliminar factura: " + e.getMessage() + "</div>");
                out.println("<a href='ServAllFacturasVenta' class='volver'>← Volver a facturas</a>");
                out.println("</div></body></html>");
            } finally {
                if (conn != null) {
                    try { conn.setAutoCommit(true); conn.close(); } catch (Exception ex) { }
                }
            }
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        processRequest(req, resp);
    }
}