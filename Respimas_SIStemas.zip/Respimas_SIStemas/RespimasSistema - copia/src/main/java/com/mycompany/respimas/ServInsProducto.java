/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.respimas;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ianac
 */
@WebServlet("/ServInsProducto")
public class ServInsProducto extends HttpServlet {
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String sku = request.getParameter("sku");
            String catalogo = request.getParameter("catalogo");
            String codigoSat = request.getParameter("codigo_sat");
            String descripcion = request.getParameter("descripcion");
            String marca = request.getParameter("marca");
            double precioCliente = Double.parseDouble(request.getParameter("precio_cliente"));
            double precioProveedor = Double.parseDouble(request.getParameter("precio_proveedor"));
            int stockMinimo = Integer.parseInt(request.getParameter("stock_minimo"));
            int existenciaActual = Integer.parseInt(request.getParameter("existencia_actual"));

            String sql = "INSERT INTO PRODUCTO (SKU, CATALOGO, CODIGO_SAT, descripcion, marca, precio_cliente, precio_proveedor, stock_minimo, existencia_actual) VALUES (?,?,?,?,?,?,?,?,?)";
            try (Connection conn = ConexionBD.getConnection();
                 PreparedStatement pst = conn.prepareStatement(sql)) {
                pst.setString(1, sku);
                pst.setString(2, catalogo);
                pst.setString(3, codigoSat);
                pst.setString(4, descripcion);
                pst.setString(5, marca);
                pst.setDouble(6, precioCliente);
                pst.setDouble(7, precioProveedor);
                pst.setInt(8, stockMinimo);
                pst.setInt(9, existenciaActual);
                int filas = pst.executeUpdate();
                if (filas > 0) {
                    out.println("<h3>Producto registrado exitosamente</h3>");
                    out.println("<a href='ServAllProductos'>Volver a productos</a>");
                } else {
                    out.println("<h3>Error al registrar producto</h3>");
                }
            } catch (Exception e) {
                out.println("<p>Error: " + e.getMessage() + "</p>");
            }
        }
    }
    @Override protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException { processRequest(req, resp); }
}