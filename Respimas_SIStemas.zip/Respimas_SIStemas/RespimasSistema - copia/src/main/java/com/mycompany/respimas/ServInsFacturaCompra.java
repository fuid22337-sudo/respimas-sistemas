/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.respimas;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Date;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ianac
 */
@WebServlet("/ServInsFacturaCompra")
public class ServInsFacturaCompra extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String folio = request.getParameter("folio_proveedor");
            Date fecha = Date.valueOf(request.getParameter("fecha"));
            double monto = Double.parseDouble(request.getParameter("monto_total"));
            Double iva = request.getParameter("iva") != null && !request.getParameter("iva").isEmpty() ? Double.parseDouble(request.getParameter("iva")) : null;
            Date fechaVenc = Date.valueOf(request.getParameter("fecha_vencimiento"));
            Date fechaPago = request.getParameter("fecha_pago") != null && !request.getParameter("fecha_pago").isEmpty() ? Date.valueOf(request.getParameter("fecha_pago")) : null;
            String estatus = request.getParameter("estatus");
            String numOrden = request.getParameter("num_orden");

            if (numOrden != null && numOrden.isEmpty()) numOrden = null;

            Connection conn = null;
            try {
                conn = ConexionBD.getConnection();
                conn.setAutoCommit(false);

                // 1. Insertar factura de compra
                String sqlIns = "INSERT INTO FACTURA_COMPRA (folio_proveedor, fecha, monto_total, IVA, fecha_vencimiento, fecha_pago, estatus, num_orden) VALUES (?,?,?,?,?,?,?,?)";
                try (PreparedStatement pst = conn.prepareStatement(sqlIns)) {
                    pst.setString(1, folio);
                    pst.setDate(2, fecha);
                    pst.setDouble(3, monto);
                    pst.setObject(4, iva);
                    pst.setDate(5, fechaVenc);
                    pst.setDate(6, fechaPago);
                    pst.setString(7, estatus);
                    pst.setString(8, numOrden);
                    pst.executeUpdate();
                }

                // 2. Si hay orden asociada, verificar si necesita ser recibida
                if (numOrden != null) {
                    String sqlCheck = "SELECT estatus FROM ORDEN_COMPRA WHERE num_orden = ?";
                    PreparedStatement pstCheck = conn.prepareStatement(sqlCheck);
                    pstCheck.setString(1, numOrden);
                    ResultSet rsCheck = pstCheck.executeQuery();
                    if (rsCheck.next()) {
                        String estatusOrden = rsCheck.getString("estatus");
                        rsCheck.close();

                        if ("Enviada".equals(estatusOrden)) {
                            // Cambiar estatus a Recibida
                            String sqlUpdEst = "UPDATE ORDEN_COMPRA SET estatus = 'Recibida' WHERE num_orden = ?";
                            PreparedStatement pstUpdEst = conn.prepareStatement(sqlUpdEst);
                            pstUpdEst.setString(1, numOrden);
                            pstUpdEst.executeUpdate();

                            // Obtener líneas de detalle y hacer entrada de inventario
                            String sqlDet = "SELECT SKU, cantidad FROM DETALLE_ORDEN WHERE num_orden = ?";
                            PreparedStatement pstDet = conn.prepareStatement(sqlDet);
                            pstDet.setString(1, numOrden);
                            ResultSet rsDet = pstDet.executeQuery();

                            String sqlUpdProd = "UPDATE PRODUCTO SET existencia_actual = existencia_actual + ? WHERE SKU = ?";
                            String sqlMov = "INSERT INTO MOVIMIENTO_INVENTARIO (fecha, tipo, cantidad, referencia, SKU) VALUES (CURDATE(), 'entrada', ?, ?, ?)";
                            PreparedStatement pstProd = conn.prepareStatement(sqlUpdProd);
                            PreparedStatement pstMov = conn.prepareStatement(sqlMov);

                            while (rsDet.next()) {
                                String sku = rsDet.getString("SKU");
                                int cantidad = rsDet.getInt("cantidad");

                                pstProd.setInt(1, cantidad);
                                pstProd.setString(2, sku);
                                pstProd.executeUpdate();

                                pstMov.setInt(1, cantidad);
                                pstMov.setString(2, numOrden);
                                pstMov.setString(3, sku);
                                pstMov.executeUpdate();
                            }
                            rsDet.close();
                        }
                    } else {
                        throw new Exception("La orden especificada no existe.");
                    }
                }

                conn.commit();

                out.println("<!DOCTYPE html><html><head><title>Factura Compra</title>");
                out.println("<link rel='stylesheet' type='text/css' href='estilos.css'>");
                out.println("</head><body><div class='container'>");
                out.println("<div class='mensaje mensaje-exito'>Factura de compra registrada correctamente.</div>");
                if (numOrden != null) {
                    out.println("<p>La orden " + numOrden + " ha sido marcada como Recibida y el inventario se ha actualizado.</p>");
                }
                out.println("<a href='ServAllFacturasCompra' class='volver'>← Ver facturas de compra</a>");
                out.println("</div></body></html>");

            } catch (Exception e) {
                if (conn != null) {
                    try { conn.rollback(); } catch (Exception ex) {}
                }
                out.println("<!DOCTYPE html><html><head><title>Error</title>");
                out.println("<link rel='stylesheet' type='text/css' href='estilos.css'>");
                out.println("</head><body><div class='container'>");
                out.println("<div class='mensaje mensaje-error'>Error: " + e.getMessage() + "</div>");
                out.println("<a href='formAltaFacturaCompra2.jsp' class='volver'>← Volver al formulario</a>");
                out.println("</div></body></html>");
            } finally {
                if (conn != null) {
                    try { conn.setAutoCommit(true); conn.close(); } catch (Exception ex) {}
                }
            }
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        processRequest(req, resp);
    }
}