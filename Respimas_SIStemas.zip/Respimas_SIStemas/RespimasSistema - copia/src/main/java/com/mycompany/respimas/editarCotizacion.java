/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.respimas;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Date;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 *
 * @author ianac
 */
@WebServlet("/editarCotizacion")
public class editarCotizacion extends HttpServlet {

    // -------------------------------------------------------
    // GET: muestra el formulario de edición con los datos actuales
    // -------------------------------------------------------
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String numCotizacion = req.getParameter("num_cotizacion");
        resp.setContentType("text/html;charset=UTF-8");
        PrintWriter out = resp.getWriter();

        out.println("<!DOCTYPE html><html><head><title>Editar Cotización</title>");
        out.println("<link rel='stylesheet' type='text/css' href='estilos.css'>");
        out.println("</head><body class='page-layout'><div class='container'>");
        out.println("<h2>Editar Cotización</h2>");

        try (Connection conn = ConexionBD.getConnection();
             PreparedStatement pst = conn.prepareStatement("SELECT * FROM COTIZACION WHERE num_cotizacion = ?")) {
            pst.setString(1, numCotizacion);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                out.println("<form action='editarCotizacion' method='post'>");
                out.println("<input type='hidden' name='num_cotizacion' value='" + rs.getString("num_cotizacion") + "'>");

                out.println("<label>Número de Cotización:</label>");
                out.println("<input type='text' value='" + rs.getString("num_cotizacion") + "' disabled>");

                out.println("<label>Fecha:</label>");
                out.println("<input type='date' name='fecha' value='" + rs.getDate("fecha") + "' required>");

                out.println("<label>Vigencia:</label>");
                out.println("<input type='date' name='vigencia' value='" + rs.getDate("vigencia") + "'>");

                out.println("<label>Estatus:</label>");
                out.println("<select name='estatus'>");
                out.println("<option value='Activa'" + ("Activa".equals(rs.getString("estatus")) ? "selected" : "") + ">Activa</option>");
                out.println("<option value='Vencida'" + ("Vencida".equals(rs.getString("estatus")) ? "selected" : "") + ">Vencida</option>");
                out.println("<option value='Aceptada'" + ("Aceptada".equals(rs.getString("estatus")) ? "selected" : "") + ">Aceptada</option>");
                out.println("</select>");

                out.println("<label>Cliente:</label>");
                out.println("<select name='cliente_RFC' required>");
                try (Statement stmt = conn.createStatement();
                     ResultSet rsCli = stmt.executeQuery("SELECT RFC, nombre_comercial FROM CLIENTE ORDER BY nombre_comercial")) {
                    while (rsCli.next()) {
                        String selected = rsCli.getString("RFC").equals(rs.getString("cliente_RFC")) ? "selected" : "";
                        out.println("<option value='" + rsCli.getString("RFC") + "' " + selected + ">" +
                                    rsCli.getString("nombre_comercial") + " (" + rsCli.getString("RFC") + ")</option>");
                    }
                }
                out.println("</select>");

                out.println("<br><input type='submit' value='Actualizar' class='accion-agregar'>");
                out.println("</form>");
            } else {
                out.println("<div class='mensaje mensaje-error'>Cotización no encontrada.</div>");
            }
        } catch (Exception e) {
            out.println("<div class='mensaje mensaje-error'>Error: " + e.getMessage() + "</div>");
        }
        out.println("<br><a href='ServAllCotizaciones' class='volver'>← Cancelar</a>");
        out.println("</div></body></html>");
    }

    // -------------------------------------------------------
    // POST: actualiza la cotización (lógica original sin cambios)
    // -------------------------------------------------------
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String numCotizacion = req.getParameter("num_cotizacion");
        Date fecha = Date.valueOf(req.getParameter("fecha"));
        Date vigencia = req.getParameter("vigencia") != null && !req.getParameter("vigencia").isEmpty() ?
                        Date.valueOf(req.getParameter("vigencia")) : null;
        String estatus = req.getParameter("estatus");
        String clienteRFC = req.getParameter("cliente_RFC");

        String sql = "UPDATE COTIZACION SET fecha=?, vigencia=?, estatus=?, cliente_RFC=? WHERE num_cotizacion=?";
        try (Connection conn = ConexionBD.getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setDate(1, fecha);
            pst.setDate(2, vigencia);
            pst.setString(3, estatus);
            pst.setString(4, clienteRFC);
            pst.setString(5, numCotizacion);
            pst.executeUpdate();
            resp.sendRedirect("ServAllCotizaciones");
        } catch (Exception e) {
            try (PrintWriter out = resp.getWriter()) {
                out.println("<div class='mensaje mensaje-error'>Error al actualizar: " + e.getMessage() + "</div>");
            }
        }
    }
}