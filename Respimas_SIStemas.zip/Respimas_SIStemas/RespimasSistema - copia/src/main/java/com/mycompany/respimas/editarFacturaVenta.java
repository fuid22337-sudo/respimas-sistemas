/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.respimas;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/**
 *
 * @author ianac
 */
@WebServlet("/editarFacturaVenta")
public class editarFacturaVenta extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String folioOriginal = request.getParameter("folio_original");
            String nuevoFolio = request.getParameter("folio");
            String fecha = request.getParameter("fecha");
            String clienteRFC = request.getParameter("cliente_RFC");
            String estatus = request.getParameter("estatus");
            String fechaPago = request.getParameter("fecha_pago");
            String movimientoBanco = request.getParameter("movimiento_banco");

            String[] skus = request.getParameterValues("sku[]");
            String[] cantidadesStr = request.getParameterValues("cantidad[]");
            String[] preciosStr = request.getParameterValues("precio[]");

            if (skus == null || cantidadesStr == null || preciosStr == null || skus.length == 0) {
                out.println("<h3>Error: debe tener al menos un producto.</h3>");
                out.println("<a href='ServAllFacturasVenta'>Volver</a>");
                return;
            }

            double montoTotal = 0;
            int[] cantidades = new int[skus.length];
            double[] precios = new double[skus.length];
            for (int i = 0; i < skus.length; i++) {
                cantidades[i] = Integer.parseInt(cantidadesStr[i]);
                precios[i] = Double.parseDouble(preciosStr[i]);
                montoTotal += cantidades[i] * precios[i];
            }

            Connection conn = null;
            try {
                conn = ConexionBD.getConnection();
                conn.setAutoCommit(false);

                // 1. Revertir inventario de las líneas originales
                String sqlOldLines = "SELECT SKU, cantidad FROM MOVIMIENTO_INVENTARIO WHERE referencia = ? AND tipo = 'salida'";
                PreparedStatement pstOld = conn.prepareStatement(sqlOldLines);
                pstOld.setString(1, folioOriginal);
                ResultSet rsOld = pstOld.executeQuery();
                String sqlRevert = "UPDATE PRODUCTO SET existencia_actual = existencia_actual + ? WHERE SKU = ?";
                PreparedStatement pstRevert = conn.prepareStatement(sqlRevert);
                while (rsOld.next()) {
                    pstRevert.setInt(1, rsOld.getInt("cantidad"));
                    pstRevert.setString(2, rsOld.getString("SKU"));
                    pstRevert.executeUpdate();
                }
                rsOld.close();

                // 2. Eliminar movimientos antiguos
                String sqlDelMov = "DELETE FROM MOVIMIENTO_INVENTARIO WHERE referencia = ? AND tipo = 'salida'";
                PreparedStatement pstDel = conn.prepareStatement(sqlDelMov);
                pstDel.setString(1, folioOriginal);
                pstDel.executeUpdate();

                // 3. Actualizar cabecera de la factura (permite cambiar folio)
                String sqlUpdate = "UPDATE FACTURA_VENTA SET folio = ?, fecha = ?, monto_total = ?, estatus = ?, fecha_pago = ?, movimiento_banco = ?, cliente_RFC = ? WHERE folio = ?";
                PreparedStatement pstUpd = conn.prepareStatement(sqlUpdate);
                pstUpd.setString(1, nuevoFolio);
                pstUpd.setString(2, fecha);
                pstUpd.setDouble(3, montoTotal);
                pstUpd.setString(4, estatus);
                pstUpd.setString(5, (fechaPago != null && !fechaPago.isEmpty()) ? fechaPago : null);
                pstUpd.setString(6, movimientoBanco);
                pstUpd.setString(7, clienteRFC);
                pstUpd.setString(8, folioOriginal);
                pstUpd.executeUpdate();

                // 4. Validar stock y aplicar nuevas líneas
                String sqlCheck = "SELECT existencia_actual FROM PRODUCTO WHERE SKU = ?";
                String sqlUpdInv = "UPDATE PRODUCTO SET existencia_actual = existencia_actual - ? WHERE SKU = ?";
                String sqlInsMov = "INSERT INTO MOVIMIENTO_INVENTARIO (fecha, tipo, cantidad, referencia, SKU) VALUES (CURDATE(), 'salida', ?, ?, ?)";

                PreparedStatement pstCheck = conn.prepareStatement(sqlCheck);
                PreparedStatement pstInv = conn.prepareStatement(sqlUpdInv);
                PreparedStatement pstMov = conn.prepareStatement(sqlInsMov);

                for (int i = 0; i < skus.length; i++) {
                    pstCheck.setString(1, skus[i]);
                    ResultSet rsChk = pstCheck.executeQuery();
                    int exist = 0;
                    if (rsChk.next()) {
                        exist = rsChk.getInt("existencia_actual");
                    } else {
                        throw new Exception("Producto " + skus[i] + " no existe.");
                    }
                    rsChk.close();

                    if (exist < cantidades[i]) {
                        throw new Exception("Stock insuficiente para " + skus[i] + ". Disponible: " + exist + ", solicitado: " + cantidades[i]);
                    }

                    pstInv.setInt(1, cantidades[i]);
                    pstInv.setString(2, skus[i]);
                    pstInv.executeUpdate();

                    pstMov.setInt(1, cantidades[i]);
                    pstMov.setString(2, nuevoFolio);
                    pstMov.setString(3, skus[i]);
                    pstMov.executeUpdate();
                }

                conn.commit();
                out.println("<h3>Factura actualizada correctamente.</h3>");
                out.println("<a href='ServAllFacturasVenta'>Ver facturas</a>");
            } catch (Exception e) {
                if (conn != null) try { conn.rollback(); } catch (Exception ex) {}
                out.println("<div class='mensaje mensaje-error'>Error al editar factura: " + e.getMessage() + "</div>");
                out.println("<a href='ServAllFacturasVenta'>Volver</a>");
            } finally {
                if (conn != null) try { conn.setAutoCommit(true); conn.close(); } catch (Exception ex) {}
            }
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        processRequest(req, resp);
    }
}