/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.respimas;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author ianac
 */
public class InventarioService {

    /**
     * Aumenta el inventario de los productos de una orden de compra (cuando se recibe).
     * @param conn Conexión activa (transacción)
     * @param numOrden Número de la orden de compra
     * @throws SQLException
     */
    public static void aumentarInventarioPorOrden(Connection conn, String numOrden) throws SQLException {
        String sql = "UPDATE PRODUCTO p " +
                     "JOIN DETALLE_ORDEN d ON p.SKU = d.SKU " +
                     "SET p.existencia_actual = p.existencia_actual + d.cantidad " +
                     "WHERE d.num_orden = ?";
        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, numOrden);
            pst.executeUpdate();
        }
    }

    /**
     * Disminuye el inventario de los productos de una orden de compra (si se cancela después de recibida).
     * @param conn Conexión activa (transacción)
     * @param numOrden Número de la orden de compra
     * @throws SQLException
     */
    public static void disminuirInventarioPorOrden(Connection conn, String numOrden) throws SQLException {
        String sql = "UPDATE PRODUCTO p " +
                     "JOIN DETALLE_ORDEN d ON p.SKU = d.SKU " +
                     "SET p.existencia_actual = p.existencia_actual - d.cantidad " +
                     "WHERE d.num_orden = ?";
        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, numOrden);
            pst.executeUpdate();
        }
    }
}