/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.respimas;

import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

/**
 *
 * @author ianac
 */
@WebServlet("/editarUsuario")
public class editarUsuario extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int id = Integer.parseInt(req.getParameter("id"));
        resp.setContentType("text/html;charset=UTF-8");
        PrintWriter out = resp.getWriter();

        out.println("<!DOCTYPE html><html><head><title>Editar Usuario</title>");
        out.println("<link rel='stylesheet' type='text/css' href='estilos.css'>");
        out.println("</head><body><div class='container'>");
        out.println("<h2>Editar Usuario</h2>");

        try (Connection conn = ConexionBD.getConnection();
             PreparedStatement pst = conn.prepareStatement("SELECT * FROM usuarios WHERE id = ?")) {
            pst.setInt(1, id);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                out.println("<form action='editarUsuario' method='post'>");
                out.println("<input type='hidden' name='id' value='" + rs.getInt("id") + "'>");
                out.println("<label>Username:</label>");
                out.println("<input type='text' value='" + rs.getString("username") + "' disabled>");
                out.println("<label>Nombre completo:</label>");
                out.println("<input type='text' name='nombre' value='" + rs.getString("nombre") + "'>");
                out.println("<label>Rol:</label>");
                out.println("<select name='rol'>");
                out.println("<option value='usuario'" + ("usuario".equals(rs.getString("rol")) ? "selected" : "") + ">Usuario</option>");
                out.println("<option value='admin'" + ("admin".equals(rs.getString("rol")) ? "selected" : "") + ">Administrador</option>");
                out.println("</select>");
                out.println("<br><input type='submit' value='Actualizar' class='accion-agregar'>");
                out.println("</form>");
            } else {
                out.println("<div class='mensaje mensaje-error'>Usuario no encontrado</div>");
            }
        } catch (Exception e) {
            out.println("<div class='mensaje mensaje-error'>Error: " + e.getMessage() + "</div>");
        }
        out.println("<br><a href='ServAllUsuarios' class='volver'>← Cancelar</a>");
        out.println("</div></body></html>");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        int id = Integer.parseInt(req.getParameter("id"));
        String nombre = req.getParameter("nombre");
        String rol = req.getParameter("rol");

        String sql = "UPDATE usuarios SET nombre=?, rol=? WHERE id=?";
        try (Connection conn = ConexionBD.getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, nombre);
            pst.setString(2, rol);
            pst.setInt(3, id);
            pst.executeUpdate();
            resp.sendRedirect("ServAllUsuarios");
        } catch (Exception e) {
            try (PrintWriter out = resp.getWriter()) {
                out.println("<div class='mensaje mensaje-error'>Error: " + e.getMessage() + "</div>");
            }
        }
    }
}