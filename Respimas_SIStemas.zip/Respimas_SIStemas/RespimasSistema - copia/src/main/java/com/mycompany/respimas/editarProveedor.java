/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.respimas;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ianac
 */
@WebServlet("/editarProveedor")
public class editarProveedor extends HttpServlet {

    // -------------------------------------------------------
    // GET: muestra el formulario de edición con los datos actuales
    // -------------------------------------------------------
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String rfc = req.getParameter("rfc");
        resp.setContentType("text/html;charset=UTF-8");
        PrintWriter out = resp.getWriter();

        out.println("<!DOCTYPE html><html><head><title>Editar Proveedor</title>");
        out.println("<link rel='stylesheet' type='text/css' href='estilos.css'>");
        out.println("</head><body><div class='container'>");
        out.println("<h2>Editar Proveedor</h2>");

        try (Connection conn = ConexionBD.getConnection();
             PreparedStatement pst = conn.prepareStatement("SELECT * FROM PROVEEDOR WHERE RFC = ?")) {
            pst.setString(1, rfc);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                out.println("<form action='editarProveedor' method='post'>");
                out.println("<input type='hidden' name='rfc' value='" + rs.getString("RFC") + "'>");

                out.println("<label>RFC:</label>");
                out.println("<input type='text' value='" + rs.getString("RFC") + "' disabled>");

                out.println("<label>Nombre:</label>");
                out.println("<input type='text' name='nombre' value='" + rs.getString("nombre") + "' required>");

                out.println("<label>Condiciones Pago:</label>");
                out.println("<input type='text' name='condiciones_pago' value='" + rs.getString("condiciones_pago") + "'>");

                out.println("<label>Contacto:</label>");
                out.println("<input type='text' name='contacto' value='" + rs.getString("contacto") + "'>");

                out.println("<label>Datos Bancarios:</label>");
                out.println("<textarea name='datos_bancarios' rows='3'>" + rs.getString("datos_bancarios") + "</textarea>");

                out.println("<br><input type='submit' value='Actualizar' class='accion-agregar'>");
                out.println("</form>");
            } else {
                out.println("<div class='mensaje mensaje-error'>Proveedor no encontrado.</div>");
            }
        } catch (Exception e) {
            out.println("<div class='mensaje mensaje-error'>Error: " + e.getMessage() + "</div>");
        }
        out.println("<br><a href='ServAllProveedores' class='volver'>← Cancelar</a>");
        out.println("</div></body></html>");
    }

    // -------------------------------------------------------
    // POST: actualiza los datos del proveedor
    // -------------------------------------------------------
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String rfc = req.getParameter("rfc");
        String nombre = req.getParameter("nombre");
        String condicionesPago = req.getParameter("condiciones_pago");
        String contacto = req.getParameter("contacto");
        String datosBancarios = req.getParameter("datos_bancarios");

        String sql = "UPDATE PROVEEDOR SET nombre=?, condiciones_pago=?, contacto=?, datos_bancarios=? WHERE RFC=?";
        try (Connection conn = ConexionBD.getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, nombre);
            pst.setString(2, condicionesPago);
            pst.setString(3, contacto);
            pst.setString(4, datosBancarios);
            pst.setString(5, rfc);
            pst.executeUpdate();
            resp.sendRedirect("ServAllProveedores");
        } catch (Exception e) {
            try (PrintWriter out = resp.getWriter()) {
                out.println("<div class='mensaje mensaje-error'>Error al actualizar: " + e.getMessage() + "</div>");
            }
        }
    }
}