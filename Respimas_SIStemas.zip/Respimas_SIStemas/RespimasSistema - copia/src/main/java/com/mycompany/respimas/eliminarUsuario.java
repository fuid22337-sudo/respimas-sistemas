/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.respimas;

import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

/**
 *
 * @author ianac
 */
@WebServlet("/eliminarUsuario")
public class eliminarUsuario extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int id = Integer.parseInt(req.getParameter("id"));
        HttpSession session = req.getSession(false);
        String sesionUsername = (String) session.getAttribute("usuario");

        try (Connection conn = ConexionBD.getConnection();
             PreparedStatement pst = conn.prepareStatement("DELETE FROM usuarios WHERE id = ? AND username != ?")) {
            pst.setInt(1, id);
            pst.setString(2, sesionUsername); // no permitir borrarse a sí mismo
            pst.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        resp.sendRedirect("ServAllUsuarios");
    }
}