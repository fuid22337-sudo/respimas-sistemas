/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.respimas;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ianac
 */
@WebServlet("/ServInsCliente")
public class ServInsCliente extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String rfc = request.getParameter("rfc");
            String nombreComercial = request.getParameter("nombre_comercial");
            String razonSocial = request.getParameter("razon_social");
            String direccion = request.getParameter("direccion");
            String telefono = request.getParameter("telefono");
            String contacto = request.getParameter("contacto");
            double limiteCredito = Double.parseDouble(request.getParameter("limite_credito"));

            String sql = "INSERT INTO CLIENTE (RFC, nombre_comercial, razon_social, direccion, telefono, contacto, limite_credito) VALUES (?,?,?,?,?,?,?)";
            try (Connection conn = ConexionBD.getConnection();
                 PreparedStatement pst = conn.prepareStatement(sql)) {
                pst.setString(1, rfc);
                pst.setString(2, nombreComercial);
                pst.setString(3, razonSocial);
                pst.setString(4, direccion);
                pst.setString(5, telefono);
                pst.setString(6, contacto);
                pst.setDouble(7, limiteCredito);
                int filas = pst.executeUpdate();
                if (filas > 0) {
                    response.sendRedirect("ServAllClientes");
                } else {
                    out.println("<h3>Error: no se pudo insertar el cliente</h3>");
                    out.println("<a href='formAltaCliente.html'>Volver al formulario</a>");
                }
            } catch (Exception e) {
                out.println("<p style='color:red;'>Error SQL: " + e.getMessage() + "</p>");
                out.println("<a href='formAltaCliente.html'>Regresar</a>");
            }
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        processRequest(req, resp);
    }
}