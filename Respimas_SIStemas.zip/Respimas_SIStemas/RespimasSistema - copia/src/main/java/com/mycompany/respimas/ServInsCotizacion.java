/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.respimas;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Date;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ianac
 */
@WebServlet("/ServInsCotizacion")
public class ServInsCotizacion extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String numCotizacion = request.getParameter("num_cotizacion");
            Date fecha = Date.valueOf(request.getParameter("fecha"));
            Date vigencia = request.getParameter("vigencia") != null && !request.getParameter("vigencia").isEmpty() ? Date.valueOf(request.getParameter("vigencia")) : null;
            String estatus = request.getParameter("estatus");
            String clienteRFC = request.getParameter("cliente_RFC");

            String sql = "INSERT INTO COTIZACION (num_cotizacion, fecha, vigencia, estatus, cliente_RFC) VALUES (?,?,?,?,?)";
            try (Connection conn = ConexionBD.getConnection();
                 PreparedStatement pst = conn.prepareStatement(sql)) {
                pst.setString(1, numCotizacion);
                pst.setDate(2, fecha);
                pst.setDate(3, vigencia);
                pst.setString(4, estatus);
                pst.setString(5, clienteRFC);
                int filas = pst.executeUpdate();
                if (filas > 0) {
                    out.println("<h3>Cotización registrada exitosamente</h3>");
                    out.println("<a href='ServAllCotizaciones'>Ver cotizaciones</a><br>");
                    out.println("<a href='formAltaDetalleCotizacion.html?num_cotizacion=" + numCotizacion + "'>Agregar productos a esta cotización</a>");
                } else {
                    out.println("<h3>Error al registrar</h3>");
                }
            } catch (Exception e) {
                out.println("<p>Error: " + e.getMessage() + "</p>");
            }
        }
    }

    @Override protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException { processRequest(req, resp); }
}