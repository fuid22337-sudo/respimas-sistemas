/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.respimas;

import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;


/**
 *
 * @author ianac
 */
@WebServlet("/ServInsUsuario")
public class ServInsUsuario extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String nombre = request.getParameter("nombre");
        String rol = request.getParameter("rol");

        // Validación de sesión y rol
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("logueado") == null) {
            response.sendRedirect("login.jsp");
            return;
        }
        String rolUsuario = (String) session.getAttribute("rol");
        if (!"admin".equals(rolUsuario)) {
            response.sendRedirect("index.jsp");
            return;
        }

        if (username == null || password == null || username.trim().isEmpty() || password.trim().isEmpty()) {
            response.sendRedirect("formAltaUsuario.jsp?error=campos");
            return;
        }

        String sql = "INSERT INTO usuarios (username, password, nombre, rol) VALUES (?, ?, ?, ?)";
        try (Connection conn = ConexionBD.getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, username.trim());
            pst.setString(2, password);  // en producción usar hash
            pst.setString(3, nombre != null ? nombre.trim() : "");
            pst.setString(4, rol != null ? rol.trim() : "usuario");
            pst.executeUpdate();
            response.sendRedirect("ServAllUsuarios");
        } catch (SQLIntegrityConstraintViolationException e) {
            response.sendRedirect("formAltaUsuario.jsp?error=duplicado");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("formAltaUsuario.jsp?error=desconocido");
        }
    }
}
