/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.respimas;



import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;
/**
 *
 * @author ianac
 */
@WebServlet("/ServLogin")
public class ServLogin extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // Validación básica de campos vacíos
        if (username == null || password == null || username.trim().isEmpty() || password.trim().isEmpty()) {
            response.sendRedirect("login.jsp?error=1");
            return;
        }

        // Consulta optimizada: un solo SELECT que trae password, nombre y rol
        String sql = "SELECT password, nombre, rol FROM usuarios WHERE username = ?";

        try (Connection conn = ConexionBD.getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setString(1, username);
            try (ResultSet rs = pst.executeQuery()) {

                if (rs.next()) {
                    String passBD = rs.getString("password");

                    // Comparación directa (en producción usar hash)
                    if (password.equals(passBD)) {
                        HttpSession session = request.getSession();
                        session.setAttribute("usuario", username);
                        session.setAttribute("nombre", rs.getString("nombre") != null ? rs.getString("nombre") : username);
                        session.setAttribute("rol", rs.getString("rol") != null ? rs.getString("rol") : "usuario");
                        session.setAttribute("logueado", true);
                        response.sendRedirect("index.jsp");
                        return;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Credenciales incorrectas
        response.sendRedirect("login.jsp?error=1");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Si alguien accede por GET, redirigir al formulario de login
        response.sendRedirect("login.jsp");
    }
}