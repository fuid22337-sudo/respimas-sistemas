/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.respimas;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ianac
 */
@WebServlet("/ServAllMovimientosInventario")
public class ServAllMovimientosInventario extends HttpServlet {
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html><html><head><title>Movimientos de Inventario</title>");
            out.println("<link rel='stylesheet' type='text/css' href='estilos.css'>");
            out.println("</head><body>");
            out.println("<header class='main-header'>");
            out.println("<div class='logo-area'><div class='company-text'><h2>RESPIMAS</h2></div></div>");
            out.println("<div class='user-area'>");
            out.println("<span class='user-greeting'>👋 <strong>" + request.getSession().getAttribute("nombre") + "</strong> (" + request.getSession().getAttribute("usuario") + ") | Rol: " + request.getSession().getAttribute("rol") + "</span>");
            out.println("<a href='ServLogout' class='logout-btn' onclick='return confirm(\"¿Cerrar sesión?\")'>Cerrar sesión</a>");
            out.println("</div>");
            out.println("</header>");
            out.println("<div class='container'>");
            out.println("<h2>Movimientos de Inventario</h2>");
            out.println("<a href='formAltaMovimientoInventario2.jsp' class='accion-agregar'>➕ Nuevo movimiento</a>");

            try (Connection conn = ConexionBD.getConnection();
                 Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery("SELECT * FROM MOVIMIENTO_INVENTARIO ORDER BY fecha DESC")) {

                out.println("<table>");
                out.println("<tr><th>ID</th><th>Fecha</th><th>Tipo</th><th>Cantidad</th><th>Referencia</th><th>SKU</th><th>Acciones</th></tr>");
                while (rs.next()) {
                    int id = rs.getInt("id_mov");
                    out.println("<tr>");
                    out.println("<td>" + id + "</td>");
                    out.println("<td>" + rs.getDate("fecha") + "</td>");
                    out.println("<td>" + rs.getString("tipo") + "</td>");
                    out.println("<td>" + rs.getInt("cantidad") + "</td>");
                    out.println("<td>" + rs.getString("referencia") + "</td>");
                    out.println("<td>" + rs.getString("SKU") + "</td>");
                    out.println("<td>");
                    out.println("<a href='editarMovimientoInventario?id=" + id + "' class='accion accion-editar'>Editar</a> ");
                    out.println("<a href='eliminarMovimientoInventario?id=" + id + "' class='accion accion-eliminar' onclick='return confirm(\"¿Eliminar?\")'>Eliminar</a>");
                    out.println("</td>");
                    out.println("</tr>");
                }
                out.println("</table>");
            } catch (Exception e) {
                out.println("<div class='mensaje mensaje-error'>Error: " + e.getMessage() + "</div>");
            }
            out.println("<a href='index.jsp' class='volver'>← Volver al inicio</a>");
            out.println("</div>");
            out.println("<footer class='main-footer'><div>© 2026 RESPIMAS · Todos los derechos reservados</div></footer>");
            out.println("</body></html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        processRequest(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        processRequest(req, resp);
    }
}