/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.respimas;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ianac
 */
@WebServlet("/editarDetalleCotizacion")
public class editarDetalleCotizacion extends HttpServlet {

    // Mostrar formulario de edición (GET)
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String numCotizacion = req.getParameter("num_cotizacion");
        String sku = req.getParameter("sku");
        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();
        out.println("<html><head><title>Editar Detalle</title></head><body>");
        out.println("<h2>Editar Detalle de Cotización</h2>");

        try (Connection conn = ConexionBD.getConnection();
             PreparedStatement pst = conn.prepareStatement("SELECT * FROM DETALLE_COTIZACION WHERE num_cotizacion=? AND SKU=?")) {
            pst.setString(1, numCotizacion);
            pst.setString(2, sku);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                out.println("<form action='editarDetalleCotizacion' method='POST'>");
                out.println("<input type='hidden' name='num_cotizacion' value='" + numCotizacion + "'>");
                out.println("<input type='hidden' name='sku' value='" + sku + "'>");
                out.println("Cantidad: <input type='number' name='cantidad' value='" + rs.getInt("cantidad") + "' required><br>");
                out.println("Precio Unitario: <input type='number' step='0.01' name='precio_unitario' value='" + rs.getBigDecimal("precio_unitario") + "' required><br>");
                out.println("<input type='submit' value='Actualizar'>");
                out.println("</form>");
            } else {
                out.println("<p>Detalle no encontrado</p>");
            }
        } catch (Exception e) {
            out.println("<p>Error: " + e.getMessage() + "</p>");
        }
        out.println("<br><a href='ServAllDetalleCotizacion?num_cotizacion=" + numCotizacion + "'>Cancelar</a>");
        out.println("</body></html>");
    }

    // Procesar la actualización (POST)
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String numCotizacion = req.getParameter("num_cotizacion");
        String sku = req.getParameter("sku");
        int cantidad = Integer.parseInt(req.getParameter("cantidad"));
        double precioUnitario = Double.parseDouble(req.getParameter("precio_unitario"));

        String sql = "UPDATE DETALLE_COTIZACION SET cantidad=?, precio_unitario=? WHERE num_cotizacion=? AND SKU=?";
        try (Connection conn = ConexionBD.getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setInt(1, cantidad);
            pst.setDouble(2, precioUnitario);
            pst.setString(3, numCotizacion);
            pst.setString(4, sku);
            pst.executeUpdate();
            resp.sendRedirect("ServAllDetalleCotizacion?num_cotizacion=" + numCotizacion);
        } catch (Exception e) {
            resp.getWriter().println("Error al actualizar: " + e.getMessage());
        }
    }
}