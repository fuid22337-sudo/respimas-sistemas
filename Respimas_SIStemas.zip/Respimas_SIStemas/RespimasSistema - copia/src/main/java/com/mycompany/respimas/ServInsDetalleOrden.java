/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.respimas;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ianac
 */
@WebServlet("/ServInsDetalleOrden")
public class ServInsDetalleOrden extends HttpServlet {
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String numOrden = request.getParameter("num_orden");
            String sku = request.getParameter("sku");
            int cantidad = Integer.parseInt(request.getParameter("cantidad"));
            double precioUnitario = Double.parseDouble(request.getParameter("precio_unitario"));

            String sql = "INSERT INTO DETALLE_ORDEN (num_orden, SKU, cantidad, precio_unitario) VALUES (?,?,?,?)";
            try (Connection conn = ConexionBD.getConnection();
                 PreparedStatement pst = conn.prepareStatement(sql)) {
                pst.setString(1, numOrden);
                pst.setString(2, sku);
                pst.setInt(3, cantidad);
                pst.setDouble(4, precioUnitario);
                int filas = pst.executeUpdate();
                if (filas > 0) {
                    out.println("<h3>Producto agregado a la orden</h3>");
                    out.println("<a href='ServAllDetalleOrden?num_orden=" + numOrden + "'>Volver a detalles</a>");
                } else {
                    out.println("<h3>Error</h3>");
                }
            } catch (Exception e) {
                out.println("<p>Error: " + e.getMessage() + "</p>");
            }
        }
    }
    @Override protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException { processRequest(req, resp); }
}