/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.respimas;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ianac
 */
@WebServlet("/ServAllProveedores")
public class ServAllProveedores extends HttpServlet {
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html><html><head><title>Proveedores</title>");
            out.println("<link rel='stylesheet' type='text/css' href='estilos.css'>");
            out.println("</head><body>");
            out.println("<header class='main-header'>");
            out.println("<div class='logo-area'><div class='company-text'><h2>RESPIMAS</h2></div></div>");
            out.println("<div class='user-area'>");
            out.println("<span class='user-greeting'>👋 <strong>" + request.getSession().getAttribute("nombre") + "</strong> (" + request.getSession().getAttribute("usuario") + ") | Rol: " + request.getSession().getAttribute("rol") + "</span>");
            out.println("<a href='ServLogout' class='logout-btn' onclick='return confirm(\"¿Cerrar sesión?\")'>Cerrar sesión</a>");
            out.println("</div>");
            out.println("</header>");
            out.println("<div class='container'>");
            out.println("<h2>Lista de Proveedores</h2>");
            out.println("<a href='formAltaProveedor2.jsp' class='accion-agregar'>➕ Agregar proveedor</a>");

            try (Connection conn = ConexionBD.getConnection();
                 Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery("SELECT * FROM PROVEEDOR ORDER BY nombre")) {

                out.println("<table>");
                out.println("<tr><th>RFC</th><th>Nombre</th><th>Condiciones Pago</th><th>Contacto</th><th>Datos Bancarios</th><th>Acciones</th></tr>");
                while (rs.next()) {
                    String rfc = rs.getString("RFC");
                    out.println("<tr>");
                    out.println("<td>" + rfc + "</td>");
                    out.println("<td>" + rs.getString("nombre") + "</td>");
                    out.println("<td>" + rs.getString("condiciones_pago") + "</td>");
                    out.println("<td>" + rs.getString("contacto") + "</td>");
                    out.println("<td>" + rs.getString("datos_bancarios") + "</td>");
                    out.println("<td>");
                    out.println("<a href='editarProveedor?rfc=" + rfc + "' class='accion accion-editar'>Editar</a> ");
                    out.println("<a href='eliminarProveedor?rfc=" + rfc + "' class='accion accion-eliminar' onclick='return confirm(\"¿Eliminar?\")'>Eliminar</a>");
                    out.println("</td>");
                    out.println("</tr>");
                }
                out.println("</table>");
            } catch (Exception e) {
                out.println("<div class='mensaje mensaje-error'>Error: " + e.getMessage() + "</div>");
            }
            out.println("<a href='index.jsp' class='volver'>← Volver al inicio</a>");
            out.println("</div>");
            out.println("<footer class='main-footer'><div>© 2026 RESPIMAS · Todos los derechos reservados</div></footer>");
            out.println("</body></html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        processRequest(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        processRequest(req, resp);
    }
}