/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.respimas;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ianac
 */
@WebServlet("/editarProducto")
public class editarProducto extends HttpServlet {

    // -------------------------------------------------------
    // GET: muestra el formulario de edición con los datos actuales
    // -------------------------------------------------------
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String sku = req.getParameter("sku");
        resp.setContentType("text/html;charset=UTF-8");
        PrintWriter out = resp.getWriter();

        out.println("<!DOCTYPE html><html><head><title>Editar Producto</title>");
        out.println("<link rel='stylesheet' type='text/css' href='estilos.css'>");
        out.println("</head><body><div class='container'>");
        out.println("<h2>Editar Producto</h2>");

        try (Connection conn = ConexionBD.getConnection();
             PreparedStatement pst = conn.prepareStatement("SELECT * FROM PRODUCTO WHERE SKU = ?")) {
            pst.setString(1, sku);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                out.println("<form action='editarProducto' method='post'>");
                out.println("<input type='hidden' name='sku' value='" + rs.getString("SKU") + "'>");

                out.println("<label>SKU:</label>");
                out.println("<input type='text' value='" + rs.getString("SKU") + "' disabled>");

                out.println("<label>Catálogo:</label>");
                out.println("<input type='text' name='catalogo' value='" + rs.getString("CATALOGO") + "'>");

                out.println("<label>Código SAT:</label>");
                out.println("<input type='text' name='codigo_sat' value='" + rs.getString("CODIGO_SAT") + "'>");

                out.println("<label>Descripción:</label>");
                out.println("<textarea name='descripcion' rows='3'>" + rs.getString("descripcion") + "</textarea>");

                out.println("<label>Marca:</label>");
                out.println("<input type='text' name='marca' value='" + rs.getString("marca") + "'>");

                out.println("<label>Precio Cliente:</label>");
                out.println("<input type='number' step='0.01' name='precio_cliente' value='" + rs.getDouble("precio_cliente") + "' required>");

                out.println("<label>Precio Proveedor:</label>");
                out.println("<input type='number' step='0.01' name='precio_proveedor' value='" + rs.getDouble("precio_proveedor") + "' required>");

                out.println("<label>Stock Mínimo:</label>");
                out.println("<input type='number' name='stock_minimo' value='" + rs.getInt("stock_minimo") + "'>");

                out.println("<label>Existencia Actual:</label>");
                out.println("<input type='number' name='existencia_actual' value='" + rs.getInt("existencia_actual") + "'>");

                out.println("<br><input type='submit' value='Actualizar' class='accion-agregar'>");
                out.println("</form>");
            } else {
                out.println("<div class='mensaje mensaje-error'>Producto no encontrado.</div>");
            }
        } catch (Exception e) {
            out.println("<div class='mensaje mensaje-error'>Error: " + e.getMessage() + "</div>");
        }
        out.println("<br><a href='ServAllProductos' class='volver'>← Cancelar</a>");
        out.println("</div></body></html>");
    }

    // -------------------------------------------------------
    // POST: actualiza los datos del producto
    // -------------------------------------------------------
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String sku = req.getParameter("sku");
        String catalogo = req.getParameter("catalogo");
        String codigoSat = req.getParameter("codigo_sat");
        String descripcion = req.getParameter("descripcion");
        String marca = req.getParameter("marca");
        double precioCliente = Double.parseDouble(req.getParameter("precio_cliente"));
        double precioProveedor = Double.parseDouble(req.getParameter("precio_proveedor"));
        int stockMinimo = Integer.parseInt(req.getParameter("stock_minimo"));
        int existenciaActual = Integer.parseInt(req.getParameter("existencia_actual"));

        String sql = "UPDATE PRODUCTO SET CATALOGO=?, CODIGO_SAT=?, descripcion=?, marca=?, precio_cliente=?, precio_proveedor=?, stock_minimo=?, existencia_actual=? WHERE SKU=?";
        try (Connection conn = ConexionBD.getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, catalogo);
            pst.setString(2, codigoSat);
            pst.setString(3, descripcion);
            pst.setString(4, marca);
            pst.setDouble(5, precioCliente);
            pst.setDouble(6, precioProveedor);
            pst.setInt(7, stockMinimo);
            pst.setInt(8, existenciaActual);
            pst.setString(9, sku);
            pst.executeUpdate();
            resp.sendRedirect("ServAllProductos");
        } catch (Exception e) {
            try (PrintWriter out = resp.getWriter()) {
                out.println("<div class='mensaje mensaje-error'>Error al actualizar: " + e.getMessage() + "</div>");
            }
        }
    }
}