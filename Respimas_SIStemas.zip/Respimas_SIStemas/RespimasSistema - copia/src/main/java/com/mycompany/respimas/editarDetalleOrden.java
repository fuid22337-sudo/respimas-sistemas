/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.respimas;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ianac
 */
@WebServlet("/editarDetalleOrden")
public class editarDetalleOrden extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String numOrden = req.getParameter("num_orden");
        String sku = req.getParameter("sku");
        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();
        out.println("<html><body><h2>Editar Detalle Orden</h2>");
        try (Connection conn = ConexionBD.getConnection();
             PreparedStatement pst = conn.prepareStatement("SELECT * FROM DETALLE_ORDEN WHERE num_orden = ? AND SKU = ?")) {
            pst.setString(1, numOrden);
            pst.setString(2, sku);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                out.println("<form action='editarDetalleOrden' method='POST'>");
                out.println("<input type='hidden' name='num_orden' value='" + numOrden + "'>");
                out.println("<input type='hidden' name='sku' value='" + sku + "'>");
                out.println("Cantidad: <input type='number' name='cantidad' value='" + rs.getInt("cantidad") + "'><br>");
                out.println("Precio Unitario: <input type='number' step='0.01' name='precio_unitario' value='" + rs.getDouble("precio_unitario") + "'><br>");
                out.println("<input type='submit' value='Actualizar'>");
                out.println("</form>");
            }
        } catch (Exception e) {
            out.println("<p>Error: " + e.getMessage() + "</p>");
        }
        out.println("</body></html>");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String numOrden = req.getParameter("num_orden");
        String sku = req.getParameter("sku");
        int cantidad = Integer.parseInt(req.getParameter("cantidad"));
        double precioUnitario = Double.parseDouble(req.getParameter("precio_unitario"));

        String sql = "UPDATE DETALLE_ORDEN SET cantidad=?, precio_unitario=? WHERE num_orden=? AND SKU=?";
        try (Connection conn = ConexionBD.getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setInt(1, cantidad);
            pst.setDouble(2, precioUnitario);
            pst.setString(3, numOrden);
            pst.setString(4, sku);
            pst.executeUpdate();
            resp.sendRedirect("ServAllDetalleOrden?num_orden=" + numOrden);
        } catch (Exception e) {
            resp.getWriter().println("Error: " + e.getMessage());
        }
    }
}