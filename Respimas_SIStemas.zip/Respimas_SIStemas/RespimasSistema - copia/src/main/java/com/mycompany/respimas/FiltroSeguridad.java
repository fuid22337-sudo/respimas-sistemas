package com.mycompany.respimas;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author jemi_
 */
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebFilter;

@WebFilter("/*")
public class FiltroSeguridad implements Filter {
    
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, 
                         FilterChain chain) throws IOException, ServletException {
        
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;
        HttpSession session = req.getSession(false);
        
        String path = req.getRequestURI().substring(req.getContextPath().length());
        
        // Rutas públicas
        if (path.equals("/login.jsp") || path.equals("/ServLogin") || 
            path.equals("/ServLogout") || path.contains(".css") || 
            path.contains(".js") || path.equals("/")) {
            chain.doFilter(request, response);
            return;
        }
        
        // Verificar sesión
        if (session != null && session.getAttribute("logueado") != null) {
            chain.doFilter(request, response);
        } else {
            res.sendRedirect(req.getContextPath() + "/login.jsp?error=2");
        }
    }
}