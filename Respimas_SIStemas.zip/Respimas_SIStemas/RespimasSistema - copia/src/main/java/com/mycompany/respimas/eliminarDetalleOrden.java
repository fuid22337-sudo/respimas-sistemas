/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.respimas;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ianac
 */
@WebServlet("/eliminarDetalleOrden")
public class eliminarDetalleOrden extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String numOrden = req.getParameter("num_orden");
        String sku = req.getParameter("sku");
        try (Connection conn = ConexionBD.getConnection();
             PreparedStatement pst = conn.prepareStatement("DELETE FROM DETALLE_ORDEN WHERE num_orden=? AND SKU=?")) {
            pst.setString(1, numOrden);
            pst.setString(2, sku);
            pst.executeUpdate();
            resp.sendRedirect("ServAllDetalleOrden?num_orden=" + numOrden);
        } catch (Exception e) {
            resp.getWriter().println("Error: " + e.getMessage());
        }
    }
}