/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.respimas;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ianac
 */
@WebServlet("/ServInsOrdenCompra")
public class ServInsOrdenCompra extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String numOrden = request.getParameter("num_orden");
            String fecha = request.getParameter("fecha");
            String estatus = request.getParameter("estatus");
            String proveedorRFC = request.getParameter("proveedor_RFC");

            String[] skus = request.getParameterValues("sku[]");
            String[] cantidadesStr = request.getParameterValues("cantidad[]");
            String[] preciosStr = request.getParameterValues("precio[]");

            if (skus == null || cantidadesStr == null || preciosStr == null || skus.length == 0) {
                out.println("<h3>Error: debe agregar al menos un producto.</h3>");
                out.println("<a href='formAltaOrdenCompra2.jsp'>Volver</a>");
                return;
            }

            double subtotal = 0;
            int[] cantidades = new int[skus.length];
            double[] precios = new double[skus.length];

            for (int i = 0; i < skus.length; i++) {
                cantidades[i] = Integer.parseInt(cantidadesStr[i]);
                precios[i] = Double.parseDouble(preciosStr[i]);
                subtotal += cantidades[i] * precios[i];
            }
            double iva = subtotal * 0.16;  // ajusta tasa según tu país
            double total = subtotal + iva;

            Connection conn = null;
            try {
                conn = ConexionBD.getConnection();
                conn.setAutoCommit(false);

                // 1. Insertar cabecera
                String sqlCab = "INSERT INTO ORDEN_COMPRA (num_orden, fecha, subtotal, IVA, total, estatus, proveedor_RFC) VALUES (?,?,?,?,?,?,?)";
                try (PreparedStatement pst = conn.prepareStatement(sqlCab)) {
                    pst.setString(1, numOrden);
                    pst.setString(2, fecha);
                    pst.setDouble(3, subtotal);
                    pst.setDouble(4, iva);
                    pst.setDouble(5, total);
                    pst.setString(6, estatus);
                    pst.setString(7, proveedorRFC);
                    pst.executeUpdate();
                }

                // 2. Insertar detalle
                String sqlDet = "INSERT INTO DETALLE_ORDEN (num_orden, SKU, cantidad, precio_unitario) VALUES (?,?,?,?)";
                try (PreparedStatement pstDet = conn.prepareStatement(sqlDet)) {
                    for (int i = 0; i < skus.length; i++) {
                        pstDet.setString(1, numOrden);
                        pstDet.setString(2, skus[i]);
                        pstDet.setInt(3, cantidades[i]);
                        pstDet.setDouble(4, precios[i]);
                        pstDet.executeUpdate();
                    }
                }

                conn.commit();
                out.println("<h3>Orden de compra registrada exitosamente.</h3>");
                out.println("<a href='ServAllOrdenesCompra'>Ver órdenes</a>");
            } catch (Exception e) {
                if (conn != null) { try { conn.rollback(); } catch (Exception ex) {} }
                out.println("<div class='mensaje mensaje-error'>Error: " + e.getMessage() + "</div>");
            } finally {
                if (conn != null) { try { conn.setAutoCommit(true); conn.close(); } catch (Exception ex) {} }
            }
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        processRequest(req, resp);
    }
}