/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.respimas;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Date;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ianac
 */
@WebServlet("/ServInsMovimientoInventario")
public class ServInsMovimientoInventario extends HttpServlet {
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            Date fecha = Date.valueOf(request.getParameter("fecha"));
            String tipo = request.getParameter("tipo");
            int cantidad = Integer.parseInt(request.getParameter("cantidad"));
            String referencia = request.getParameter("referencia");
            String sku = request.getParameter("sku");

            String sql = "INSERT INTO MOVIMIENTO_INVENTARIO (fecha, tipo, cantidad, referencia, SKU) VALUES (?,?,?,?,?)";
            try (Connection conn = ConexionBD.getConnection();
                 PreparedStatement pst = conn.prepareStatement(sql)) {
                pst.setDate(1, fecha);
                pst.setString(2, tipo);
                pst.setInt(3, cantidad);
                pst.setString(4, referencia);
                pst.setString(5, sku);
                pst.executeUpdate();
                out.println("<h3>Movimiento registrado</h3><a href='ServAllMovimientosInventario'>Ver movimientos</a>");
            } catch (Exception e) { out.println("<p>Error: " + e.getMessage() + "</p>"); }
        }
    }
    @Override protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException { processRequest(req, resp); }
}