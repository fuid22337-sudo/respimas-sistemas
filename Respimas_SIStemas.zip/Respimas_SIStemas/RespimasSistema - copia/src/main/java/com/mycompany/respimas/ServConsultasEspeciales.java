/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.respimas;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author ianac
 */
@WebServlet("/ServConsultasEspeciales")
public class ServConsultasEspeciales extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // --- Verificación de sesión ---
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("logueado") == null) {
            response.sendRedirect("login.jsp");
            return;
        }
        
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html lang=\"es\">");
            out.println("<head>");
            out.println("<meta charset=\"UTF-8\">");
            out.println("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">");
            out.println("<title>Consultas Especiales - RESPIMAS</title>");
            out.println("<link rel=\"stylesheet\" type=\"text/css\" href=\"estilos.css\">");
            out.println("</head>");
            out.println("<body>");
            out.println("<div class=\"container\">");
            out.println("<h1>Consultas Avanzadas</h1>");

            try (Connection conn = ConexionBD.getConnection();
                 Statement stmt = conn.createStatement()) {

                // =====================================================
                // 1. GROUP BY
                // =====================================================
                out.println("<div class='consulta'>");
                out.println("<h2>1. Total facturado por cliente (GROUP BY)</h2>");
                String sqlGroup1 = "SELECT c.nombre_comercial, SUM(fv.monto_total) AS total_facturado " +
                                    "FROM CLIENTE c INNER JOIN FACTURA_VENTA fv ON c.RFC = fv.cliente_RFC " +
                                    "GROUP BY c.nombre_comercial";
                ResultSet rs1 = stmt.executeQuery(sqlGroup1);
                out.println("<table>");
                out.println("<tr><th>Cliente</th><th>Total Facturado</th></tr>");
                while (rs1.next()) {
                    out.println("<tr>");
                    out.println("<td>" + rs1.getString("nombre_comercial") + "</td>");
                    out.println("<td>$" + rs1.getBigDecimal("total_facturado") + "</td>");
                    out.println("</tr>");
                }
                out.println("</table>");
                out.println("</div>");

                // 2. GROUP BY con conteo
                out.println("<div class='consulta'>");
                out.println("<h2>2. Número de facturas por estatus (GROUP BY)</h2>");
                String sqlGroup2 = "SELECT estatus, COUNT(*) AS cantidad_facturas, SUM(monto_total) AS monto_total " +
                                    "FROM FACTURA_VENTA GROUP BY estatus";
                ResultSet rs2 = stmt.executeQuery(sqlGroup2);
                out.println("<table>");
                out.println("<tr><th>Estatus</th><th>Cantidad de Facturas</th><th>Monto Total</th></tr>");
                while (rs2.next()) {
                    out.println("<tr>");
                    out.println("<td>" + rs2.getString("estatus") + "</td>");
                    out.println("<td>" + rs2.getInt("cantidad_facturas") + "</td>");
                    out.println("<td>$" + rs2.getBigDecimal("monto_total") + "</td>");
                    out.println("</tr>");
                }
                out.println("</table>");
                out.println("</div>");

                // =====================================================
                // 2. HAVING
                // =====================================================
                out.println("<div class='consulta'>");
                out.println("<h2>3. Clientes con facturación mayor a $10,000 (HAVING)</h2>");
                String sqlHaving = "SELECT c.nombre_comercial, SUM(fv.monto_total) AS total_facturado " +
                                    "FROM CLIENTE c INNER JOIN FACTURA_VENTA fv ON c.RFC = fv.cliente_RFC " +
                                    "GROUP BY c.nombre_comercial HAVING SUM(fv.monto_total) > 10000";
                ResultSet rs3 = stmt.executeQuery(sqlHaving);
                out.println("<table>");
                out.println("<tr><th>Cliente</th><th>Total Facturado</th></tr>");
                while (rs3.next()) {
                    out.println("<tr>");
                    out.println("<td>" + rs3.getString("nombre_comercial") + "</td>");
                    out.println("<td>$" + rs3.getBigDecimal("total_facturado") + "</td>");
                    out.println("</tr>");
                }
                out.println("</table>");
                out.println("</div>");

                // 4. HAVING con conteo
                out.println("<div class='consulta'>");
                out.println("<h2>4. Estatus con más de 5 facturas (HAVING)</h2>");
                String sqlHaving2 = "SELECT estatus, COUNT(*) AS cantidad " +
                                     "FROM FACTURA_VENTA GROUP BY estatus HAVING COUNT(*) > 5";
                ResultSet rs4 = stmt.executeQuery(sqlHaving2);
                out.println("<table>");
                out.println("<tr><th>Estatus</th><th>Cantidad de Facturas</th></tr>");
                if (rs4.next()) {
                    do {
                        out.println("<tr>");
                        out.println("<td>" + rs4.getString("estatus") + "</td>");
                        out.println("<td>" + rs4.getInt("cantidad") + "</td>");
                        out.println("</tr>");
                    } while (rs4.next());
                } else {
                    out.println("<tr><td colspan='2'>No hay estatus con más de 5 facturas</td></tr>");
                }
                out.println("</table>");
                out.println("</div>");

                // =====================================================
                // 3. MULTITABLA
                // =====================================================
                out.println("<div class='consulta'>");
                out.println("<h2>5. Facturas con clientes y total abonado (3 tablas)</h2>");
                String sqlMultitabla = "SELECT fv.folio, fv.fecha, c.nombre_comercial, fv.monto_total, " +
                                        "COALESCE(SUM(a.monto), 0) AS total_abonado, " +
                                        "(fv.monto_total - COALESCE(SUM(a.monto), 0)) AS saldo_pendiente " +
                                        "FROM FACTURA_VENTA fv " +
                                        "INNER JOIN CLIENTE c ON fv.cliente_RFC = c.RFC " +
                                        "LEFT JOIN ABONO a ON fv.folio = a.factura_folio " +
                                        "GROUP BY fv.folio ORDER BY fv.fecha DESC";
                ResultSet rs5 = stmt.executeQuery(sqlMultitabla);
                out.println("<table>");
                out.println("<tr><th>Folio</th><th>Fecha</th><th>Cliente</th><th>Monto Total</th><th>Total Abonado</th><th>Saldo Pendiente</th></tr>");
                while (rs5.next()) {
                    out.println("<tr>");
                    out.println("<td>" + rs5.getString("folio") + "</td>");
                    out.println("<td>" + rs5.getDate("fecha") + "</td>");
                    out.println("<td>" + rs5.getString("nombre_comercial") + "</td>");
                    out.println("<td>$" + rs5.getBigDecimal("monto_total") + "</td>");
                    out.println("<td>$" + rs5.getBigDecimal("total_abonado") + "</td>");
                    out.println("<td>$" + rs5.getBigDecimal("saldo_pendiente") + "</td>");
                    out.println("</tr>");
                }
                out.println("</table>");
                out.println("</div>");

                // 6. Multitabla proveedores + órdenes
                out.println("<div class='consulta'>");
                out.println("<h2>6. Órdenes de compra por proveedor</h2>");
                String sqlMultitabla2 = "SELECT p.nombre AS proveedor, COUNT(oc.num_orden) AS total_ordenes, SUM(oc.total) AS monto_total " +
                                         "FROM PROVEEDOR p LEFT JOIN ORDEN_COMPRA oc ON p.RFC = oc.proveedor_RFC " +
                                         "GROUP BY p.nombre ORDER BY monto_total DESC";
                ResultSet rs6 = stmt.executeQuery(sqlMultitabla2);
                out.println("<table>");
                out.println("<tr><th>Proveedor</th><th>Total Órdenes</th><th>Monto Total</th></tr>");
                while (rs6.next()) {
                    out.println("<tr>");
                    out.println("<td>" + rs6.getString("proveedor") + "</td>");
                    out.println("<td>" + rs6.getInt("total_ordenes") + "</td>");
                    out.println("<td>$" + (rs6.getBigDecimal("monto_total") != null ? rs6.getBigDecimal("monto_total") : "0") + "</td>");
                    out.println("</tr>");
                }
                out.println("</table>");
                out.println("</div>");

            } catch (Exception e) {
                out.println("<div class='mensaje mensaje-error'>Error en consultas: " + e.getMessage() + "</div>");
            }

            out.println("<br><a href='index.jsp' class='volver'>⬅ Volver al panel</a>");
            out.println("</div>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        processRequest(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        processRequest(req, resp);
    }
}