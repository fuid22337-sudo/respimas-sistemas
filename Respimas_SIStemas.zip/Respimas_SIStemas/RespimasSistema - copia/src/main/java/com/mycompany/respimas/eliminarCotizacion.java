/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.respimas;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ianac
 */
@WebServlet("/eliminarCotizacion")
public class eliminarCotizacion extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String numCotizacion = req.getParameter("num_cotizacion");
        try (Connection conn = ConexionBD.getConnection();
             PreparedStatement pst = conn.prepareStatement("DELETE FROM COTIZACION WHERE num_cotizacion = ?")) {
            pst.setString(1, numCotizacion);
            pst.executeUpdate();
            resp.sendRedirect("ServAllCotizaciones");
        } catch (Exception e) { resp.getWriter().println("Error al eliminar: " + e.getMessage()); }
    }
}
