/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.respimas;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Date;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ianac
 */
@WebServlet("/editarOrdenCompra")
public class editarOrdenCompra extends HttpServlet {

    // -------------------------------------------------------
    // GET: muestra el formulario de edición con los datos actuales
    // -------------------------------------------------------
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String numOrden = req.getParameter("num_orden");
        resp.setContentType("text/html;charset=UTF-8");
        PrintWriter out = resp.getWriter();

        out.println("<!DOCTYPE html><html><head><title>Editar Orden</title>");
        out.println("<link rel='stylesheet' type='text/css' href='estilos.css'>");
        out.println("</head><body><div class='container'>");
        out.println("<h2>Editar Orden de Compra</h2>");

        try (Connection conn = ConexionBD.getConnection();
             PreparedStatement pst = conn.prepareStatement("SELECT * FROM ORDEN_COMPRA WHERE num_orden = ?")) {
            pst.setString(1, numOrden);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                out.println("<form action='editarOrdenCompra' method='post'>");
                out.println("<input type='hidden' name='num_orden' value='" + rs.getString("num_orden") + "'>");

                out.println("<label>Fecha:</label>");
                out.println("<input type='date' name='fecha' value='" + rs.getDate("fecha") + "' required>");

                out.println("<label>Proveedor:</label>");
                out.println("<select name='proveedor_RFC' required>");
                try (Statement stmtProv = conn.createStatement();
                     ResultSet rsProv = stmtProv.executeQuery("SELECT RFC, nombre FROM PROVEEDOR ORDER BY nombre")) {
                    while (rsProv.next()) {
                        String selected = rsProv.getString("RFC").equals(rs.getString("proveedor_RFC")) ? "selected" : "";
                        out.println("<option value='" + rsProv.getString("RFC") + "' " + selected + ">" +
                                    rsProv.getString("nombre") + "</option>");
                    }
                }
                out.println("</select>");

                // Subtotales e IVA se muestran como solo lectura (se recalculan si se editan líneas, pero aquí no editamos detalle)
                out.println("<label>Subtotal:</label>");
                out.println("<input type='number' step='0.01' value='" + rs.getBigDecimal("subtotal") + "' readonly>");
                out.println("<label>IVA:</label>");
                out.println("<input type='number' step='0.01' value='" + rs.getBigDecimal("IVA") + "' readonly>");
                out.println("<label>Total:</label>");
                out.println("<input type='number' step='0.01' name='total' value='" + rs.getBigDecimal("total") + "' required readonly>");

                out.println("<label>Estatus:</label>");
                out.println("<select name='estatus'>");
                String estActual = rs.getString("estatus");
                out.println("<option value='Enviada'" + ("Enviada".equals(estActual) ? "selected" : "") + ">Enviada</option>");
                out.println("<option value='Recibida'" + ("Recibida".equals(estActual) ? "selected" : "") + ">Recibida</option>");
                out.println("<option value='Cancelada'" + ("Cancelada".equals(estActual) ? "selected" : "") + ">Cancelada</option>");
                out.println("</select>");

                out.println("<br><input type='submit' value='Actualizar' class='accion-agregar'>");
                out.println("</form>");
            } else {
                out.println("<div class='mensaje mensaje-error'>Orden no encontrada.</div>");
            }
        } catch (Exception e) {
            out.println("<div class='mensaje mensaje-error'>Error: " + e.getMessage() + "</div>");
        }

        out.println("<br><a href='ServAllOrdenesCompra' class='volver'>← Volver</a>");
        out.println("</div></body></html>");
    }

    // -------------------------------------------------------
    // POST: actualiza la orden y, si cambia a Recibida, recibe el inventario
    // -------------------------------------------------------
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String numOrden = req.getParameter("num_orden");
        Date fecha = Date.valueOf(req.getParameter("fecha"));
        String estatusNuevo = req.getParameter("estatus");
        String proveedorRFC = req.getParameter("proveedor_RFC");

        // Los totales no se modifican manualmente (están como readonly), así que los tomamos de la BD o los recalculamos si fuera necesario.
        // Para simplificar, los mantenemos tal cual (el formulario no permite cambiarlos).
        // Pero debemos leerlos de la BD para mantener la integridad.
        Connection conn = null;
        try {
            conn = ConexionBD.getConnection();
            conn.setAutoCommit(false);

            // Obtener el estatus anterior y los totales actuales
            String sqlGet = "SELECT estatus, subtotal, IVA, total FROM ORDEN_COMPRA WHERE num_orden = ?";
            PreparedStatement pstGet = conn.prepareStatement(sqlGet);
            pstGet.setString(1, numOrden);
            ResultSet rsGet = pstGet.executeQuery();
            if (!rsGet.next()) {
                throw new Exception("Orden no encontrada.");
            }
            String estatusAnterior = rsGet.getString("estatus");
            double subtotal = rsGet.getDouble("subtotal");
            double iva = rsGet.getDouble("IVA");
            double total = rsGet.getDouble("total");
            rsGet.close();

            // Actualizar cabecera (sin cambiar totales)
            String sqlUpd = "UPDATE ORDEN_COMPRA SET fecha=?, estatus=?, proveedor_RFC=? WHERE num_orden=?";
            PreparedStatement pstUpd = conn.prepareStatement(sqlUpd);
            pstUpd.setDate(1, fecha);
            pstUpd.setString(2, estatusNuevo);
            pstUpd.setString(3, proveedorRFC);
            pstUpd.setString(4, numOrden);
            pstUpd.executeUpdate();

            // Si cambió a Recibida y antes no lo era, hacemos entrada de inventario
            if ("Recibida".equals(estatusNuevo) && !"Recibida".equals(estatusAnterior)) {
                // Leer líneas de detalle
                String sqlDet = "SELECT SKU, cantidad FROM DETALLE_ORDEN WHERE num_orden = ?";
                PreparedStatement pstDet = conn.prepareStatement(sqlDet);
                pstDet.setString(1, numOrden);
                ResultSet rsDet = pstDet.executeQuery();

                String sqlUpdProd = "UPDATE PRODUCTO SET existencia_actual = existencia_actual + ? WHERE SKU = ?";
                String sqlMov = "INSERT INTO MOVIMIENTO_INVENTARIO (fecha, tipo, cantidad, referencia, SKU) VALUES (CURDATE(), 'entrada', ?, ?, ?)";
                PreparedStatement pstProd = conn.prepareStatement(sqlUpdProd);
                PreparedStatement pstMov = conn.prepareStatement(sqlMov);

                while (rsDet.next()) {
                    String sku = rsDet.getString("SKU");
                    int cantidad = rsDet.getInt("cantidad");

                    pstProd.setInt(1, cantidad);
                    pstProd.setString(2, sku);
                    pstProd.executeUpdate();

                    pstMov.setInt(1, cantidad);
                    pstMov.setString(2, numOrden);
                    pstMov.setString(3, sku);
                    pstMov.executeUpdate();
                }
                rsDet.close();
            }

            conn.commit();
            resp.sendRedirect("ServAllOrdenesCompra");

        } catch (Exception e) {
            if (conn != null) {
                try { conn.rollback(); } catch (Exception ex) {}
            }
            try (PrintWriter out = resp.getWriter()) {
                out.println("<div class='mensaje mensaje-error'>Error al actualizar: " + e.getMessage() + "</div>");
                out.println("<a href='ServAllOrdenesCompra'>Volver</a>");
            } catch (IOException ex) {}
        } finally {
            if (conn != null) {
                try { conn.setAutoCommit(true); conn.close(); } catch (Exception ex) {}
            }
        }
    }
}