/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.respimas;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ianac
 */
@WebServlet("/ServMovsPorFactura")
public class ServMovsPorFactura extends HttpServlet {
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String folio = request.getParameter("folio");
        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html><html><head><title>Líneas factura " + folio + "</title>");
            out.println("<link rel='stylesheet' type='text/css' href='estilos.css'></head><body>");
            out.println("<div class='container'><h2>Productos vendidos en factura " + folio + "</h2>");
            out.println("<table><tr><th>SKU</th><th>Descripción</th><th>Cantidad</th><th>Precio unitario (aprox.)</th></tr>");
            try (Connection conn = ConexionBD.getConnection()) {
                String sql = "SELECT m.SKU, p.descripcion, m.cantidad, " +
                             "(SELECT precio_cliente FROM PRODUCTO WHERE SKU = m.SKU) AS precio " +
                             "FROM MOVIMIENTO_INVENTARIO m " +
                             "LEFT JOIN PRODUCTO p ON m.SKU = p.SKU " +
                             "WHERE m.referencia = ? AND m.tipo = 'salida'";
                PreparedStatement pst = conn.prepareStatement(sql);
                pst.setString(1, folio);
                ResultSet rs = pst.executeQuery();
                while (rs.next()) {
                    out.println("<tr>");
                    out.println("<td>" + rs.getString("SKU") + "</td>");
                    out.println("<td>" + rs.getString("descripcion") + "</td>");
                    out.println("<td>" + rs.getInt("cantidad") + "</td>");
                    out.println("<td>" + rs.getBigDecimal("precio") + "</td>");
                    out.println("</tr>");
                }
                out.println("</table>");
            } catch (Exception e) {
                out.println("<div class='mensaje mensaje-error'>Error: " + e.getMessage() + "</div>");
            }
            out.println("<a href='ServAllFacturasVenta' class='volver'>← Volver</a></div></body></html>");
        }
    }
    @Override protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException { processRequest(req, resp); }
}