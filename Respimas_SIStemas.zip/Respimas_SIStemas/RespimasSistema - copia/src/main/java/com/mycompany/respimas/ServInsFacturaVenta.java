/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.respimas;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/**
 *
 * @author ianac
 */
@WebServlet("/ServInsFacturaVenta")
public class ServInsFacturaVenta extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
    response.setContentType("text/html;charset=UTF-8");
    try (PrintWriter out = response.getWriter()) {
        String folio = request.getParameter("folio");
        String fecha = request.getParameter("fecha");
        String clienteRFC = request.getParameter("cliente_RFC");
        String estatus = request.getParameter("estatus");
        String fechaPago = request.getParameter("fecha_pago");
        String movimientoBanco = request.getParameter("movimiento_banco");

        String[] skus = request.getParameterValues("sku[]");
        String[] cantidadesStr = request.getParameterValues("cantidad[]");
        String[] preciosStr = request.getParameterValues("precio[]");

        if (skus == null || cantidadesStr == null || preciosStr == null || skus.length == 0) {
            out.println("<h3>Error: debe agregar al menos una línea de producto.</h3>");
            out.println("<a href='formAltaFacturaVenta2.jsp'>Volver</a>");
            return;
        }

        double montoTotal = 0;
        int[] cantidades = new int[skus.length];
        double[] precios = new double[skus.length];

        for (int i = 0; i < skus.length; i++) {
            cantidades[i] = Integer.parseInt(cantidadesStr[i]);
            precios[i] = Double.parseDouble(preciosStr[i]);
            montoTotal += cantidades[i] * precios[i];
        }

        Connection conn = null;
        try {
            conn = ConexionBD.getConnection();
            conn.setAutoCommit(false);

            //Insertar factura
            String sqlFactura = "INSERT INTO FACTURA_VENTA (folio, fecha, monto_total, estatus, fecha_pago, movimiento_banco, cliente_RFC) VALUES (?,?,?,?,?,?,?)";
            try (PreparedStatement pst = conn.prepareStatement(sqlFactura)) {
                pst.setString(1, folio);
                pst.setString(2, fecha);
                pst.setDouble(3, montoTotal);
                pst.setString(4, estatus);
                pst.setString(5, (fechaPago != null && !fechaPago.isEmpty()) ? fechaPago : null);
                pst.setString(6, movimientoBanco);
                pst.setString(7, clienteRFC);
                pst.executeUpdate();
            }

           //Preparar consultas para el inventario
            String sqlCheck = "SELECT existencia_actual FROM PRODUCTO WHERE SKU = ?";   // NUEVO
            String sqlUpd = "UPDATE PRODUCTO SET existencia_actual = existencia_actual - ? WHERE SKU = ?";
            String sqlMov = "INSERT INTO MOVIMIENTO_INVENTARIO (fecha, tipo, cantidad, referencia, SKU) VALUES (CURDATE(), 'salida', ?, ?, ?)";

            try (PreparedStatement pstCheck = conn.prepareStatement(sqlCheck);   // NUEVO
                 PreparedStatement pstUpd = conn.prepareStatement(sqlUpd);
                 PreparedStatement pstMov = conn.prepareStatement(sqlMov)) {

                for (int i = 0; i < skus.length; i++) {
                    //VALIDACIÓN DE STOCK
                    pstCheck.setString(1, skus[i]);
                    ResultSet rsCheck = pstCheck.executeQuery();
                    int existencia = 0;
                    if (rsCheck.next()) {
                        existencia = rsCheck.getInt("existencia_actual");
                    } else {
                        throw new Exception("El producto " + skus[i] + " no existe.");
                    }
                    rsCheck.close();

                    if (existencia < cantidades[i]) {
                        throw new Exception("Stock insuficiente para " + skus[i] + 
                                            ". Disponible: " + existencia + 
                                            ", solicitado: " + cantidades[i]);
                    }
               
                    pstUpd.setInt(1, cantidades[i]);
                    pstUpd.setString(2, skus[i]);
                    pstUpd.executeUpdate();

                    // Insertar movimiento
                    pstMov.setInt(1, cantidades[i]);
                    pstMov.setString(2, folio);
                    pstMov.setString(3, skus[i]);
                    pstMov.executeUpdate();
                }
            }

            conn.commit();
            out.println("<h3>Factura registrada exitosamente.</h3>");
            out.println("<a href='ServAllFacturasVenta'>Ver facturas</a>");
        } catch (Exception e) {
            if (conn != null) {
                try { conn.rollback(); } catch (Exception ex) { }
            }
            out.println("<div class='mensaje mensaje-error'>Error al registrar factura: " + e.getMessage() + "</div>");
            out.println("<a href='formAltaFacturaVenta2.jsp'>Volver al formulario</a>");
        } finally {
            if (conn != null) {
                try { conn.setAutoCommit(true); conn.close(); } catch (Exception ex) { }
            }
        }
    }
}

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        processRequest(req, resp);
    }
}