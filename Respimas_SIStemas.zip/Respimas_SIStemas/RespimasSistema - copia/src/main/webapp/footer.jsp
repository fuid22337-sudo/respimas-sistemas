<%-- 
    Document   : footer
    Created on : 3 jun 2026, 5:48:20 p.m.
    Author     : ianac
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<footer class="main-footer">
    <div>© 2026 RESPIMAS · Todos los derechos reservados</div>
</footer>
