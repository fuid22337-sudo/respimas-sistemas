<%-- 
    Document   : login
    Created on : 2 jun 2026, 7:18:48 p.m.
    Author     : jemi_
--%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión - RESPIMAS</title>
    <link rel="stylesheet" type="text/css" href="estilos.css">
</head>
<body id="login-page">
<div class="login-card">
    <h2>RESPIMAS</h2>
    <div class="subtitle">Sistema de Gestión</div>

    <%
        String error = request.getParameter("error");
        String logout = request.getParameter("logout");
        if (error != null) {
            if (error.equals("1")) {
                out.println("<div class='login-mensaje-error'>Usuario o contraseña incorrectos</div>");
            } else if (error.equals("2")) {
                out.println("<div class='login-mensaje-error'>Sesión expirada. Inicia sesión nuevamente</div>");
            }
        }
        if (logout != null && logout.equals("1")) {
            out.println("<div class='login-mensaje-exito'>Sesión cerrada correctamente</div>");
        }
    %>

    <form action="ServLogin" method="post">
        <input type="text" name="username" placeholder="Usuario" required>
        <input type="password" name="password" placeholder="Contraseña" required>
        <input type="submit" value="Ingresar">
    </form>
</div>
</body>
</html>
