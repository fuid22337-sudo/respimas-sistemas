<%-- 
    Document   : formEditarFacturaVenta
    Created on : 2 jun 2026, 7:50:27 a.m.
    Author     : ianac
--%>
 <%
    if (session == null || session.getAttribute("logueado") == null) {
        response.sendRedirect("login.jsp");
        return;
    }
%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ include file="header.jsp" %>
<%@page import="java.sql.*, com.mycompany.respimas.ConexionBD" %>
<%
    String folio = request.getParameter("folio");
    // Variables para los datos de la factura
    String clienteRFC = "", estatus = "", fecha = "", fechaPago = "", movimientoBanco = "";
    // Listas para las líneas existentes
    java.util.List<String[]> lineas = new java.util.ArrayList<>(); // {sku, cantidad}
    try (Connection conn = ConexionBD.getConnection()) {
        // 1. Obtener cabecera
        PreparedStatement pst = conn.prepareStatement("SELECT * FROM FACTURA_VENTA WHERE folio = ?");
        pst.setString(1, folio);
        ResultSet rs = pst.executeQuery();
        if (rs.next()) {
            clienteRFC = rs.getString("cliente_RFC");
            estatus = rs.getString("estatus");
            fecha = rs.getDate("fecha").toString();
            fechaPago = rs.getDate("fecha_pago") != null ? rs.getDate("fecha_pago").toString() : "";
            movimientoBanco = rs.getString("movimiento_banco") != null ? rs.getString("movimiento_banco") : "";
        } else {
            out.println("<div class='mensaje mensaje-error'>Factura no encontrada.</div>");
            return;
        }
        rs.close();
        
        // 2. Obtener movimientos de salida (líneas vendidas)
        PreparedStatement pstMov = conn.prepareStatement(
            "SELECT m.SKU, m.cantidad, p.precio_cliente FROM MOVIMIENTO_INVENTARIO m " +
            "INNER JOIN PRODUCTO p ON m.SKU = p.SKU WHERE m.referencia = ? AND m.tipo = 'salida'");
        pstMov.setString(1, folio);
        ResultSet rsMov = pstMov.executeQuery();
        while (rsMov.next()) {
            lineas.add(new String[]{
                rsMov.getString("SKU"),
                String.valueOf(rsMov.getInt("cantidad")),
                rsMov.getBigDecimal("precio_cliente").toString()
            });
        }
        rsMov.close();
    } catch (Exception e) {
        out.println("<div class='mensaje mensaje-error'>Error al cargar factura: " + e.getMessage() + "</div>");
        return;
    }
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Editar Factura <%= folio %></title>
    <link rel="stylesheet" type="text/css" href="estilos.css">
    <style>
        form { max-width: 800px; }
    </style>
</head>
<body>
<div class="container">
    <h2>Editar Factura <%= folio %></h2>
    <form action="editarFacturaVenta" method="post">
        <input type="hidden" name="folio_original" value="<%= folio %>">
        <label>Folio:</label>
        <input type="text" name="folio" value="<%= folio %>" required>

        <label>Fecha:</label>
        <input type="date" name="fecha" value="<%= fecha %>" required>

        <label>Cliente:</label>
        <select name="cliente_RFC" required>
            <option value="">-- Seleccione --</option>
            <%
                try (Connection conn = ConexionBD.getConnection();
                     Statement stmt = conn.createStatement();
                     ResultSet rs = stmt.executeQuery("SELECT RFC, nombre_comercial FROM CLIENTE ORDER BY nombre_comercial")) {
                    while (rs.next()) {
                        String selected = rs.getString("RFC").equals(clienteRFC) ? "selected" : "";
            %>
                        <option value="<%= rs.getString("RFC") %>" <%= selected %>>
                            <%= rs.getString("nombre_comercial") %> (<%= rs.getString("RFC") %>)
                        </option>
            <%      }
                }
            %>
        </select>

        <label>Estatus:</label>
        <select name="estatus">
            <option value="Pendiente" <%= estatus.equals("Pendiente") ? "selected" : "" %>>Pendiente</option>
            <option value="Pagada" <%= estatus.equals("Pagada") ? "selected" : "" %>>Pagada</option>
            <option value="Cancelada" <%= estatus.equals("Cancelada") ? "selected" : "" %>>Cancelada</option>
        </select>

        <label>Fecha Pago:</label>
        <input type="date" name="fecha_pago" value="<%= fechaPago %>">

        <label>Movimiento Banco:</label>
        <input type="text" name="movimiento_banco" value="<%= movimientoBanco %>">

        <h3>Productos</h3>
        <table id="tablaLineas">
            <thead><tr><th>Producto</th><th>Cantidad</th><th>Precio Unitario</th><th></th></tr></thead>
            <tbody id="lineas"></tbody>
        </table>
        <button type="button" onclick="agregarLinea()">➕ Agregar línea</button><br><br>

        <input type="submit" value="Guardar Cambios">
    </form>
    <br><a href="ServAllFacturasVenta" class="volver">← Cancelar</a>
</div>

<script>
    var productos = [];
    <%
        try (Connection conn = ConexionBD.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT SKU, descripcion, precio_cliente FROM PRODUCTO ORDER BY SKU")) {
            while (rs.next()) {
    %>
                productos.push({
                    sku: "<%= rs.getString("SKU") %>",
                    desc: "<%= rs.getString("descripcion").replace("\"", "\\\"") %>",
                    precio: <%= rs.getDouble("precio_cliente") %>
                });
    <%      }
        }
    %>

    function crearSelectProducto() {
        var select = document.createElement("select");
        select.name = "sku[]";
        select.required = true;
        select.innerHTML = '<option value="">-- Seleccione --</option>';
        productos.forEach(function(p) {
            var opt = document.createElement("option");
            opt.value = p.sku;
            opt.textContent = p.sku + " - " + p.desc;
            opt.setAttribute("data-precio", p.precio);
            select.appendChild(opt);
        });
        return select;
    }

    function agregarLinea(skuInicial, cantInicial, precioInicial) {
        var tbody = document.getElementById("lineas");
        var fila = tbody.insertRow();
        var celda1 = fila.insertCell(0);
        var celda2 = fila.insertCell(1);
        var celda3 = fila.insertCell(2);
        var celda4 = fila.insertCell(3);

        var select = crearSelectProducto();
        var inputCantidad = document.createElement("input");
        inputCantidad.type = "number"; inputCantidad.name = "cantidad[]"; inputCantidad.min = "1"; inputCantidad.required = true;
        var inputPrecio = document.createElement("input");
        inputPrecio.type = "number"; inputPrecio.name = "precio[]"; inputPrecio.step = "0.01"; inputPrecio.required = true;

        if (skuInicial) {
            select.value = skuInicial;
            inputCantidad.value = cantInicial;
            inputPrecio.value = precioInicial;
        } else {
            inputCantidad.value = 1;
        }

        select.addEventListener("change", function() {
            var selectedOption = this.options[this.selectedIndex];
            var precio = selectedOption.getAttribute("data-precio");
            inputPrecio.value = precio ? precio : "";
        });

        var btnQuitar = document.createElement("button");
        btnQuitar.type = "button"; btnQuitar.textContent = "Quitar";
        btnQuitar.onclick = function() { this.parentElement.parentElement.remove(); };

        celda1.appendChild(select);
        celda2.appendChild(inputCantidad);
        celda3.appendChild(inputPrecio);
        celda4.appendChild(btnQuitar);
    }

    // Cargar líneas existentes
    window.onload = function() {
    <% for (String[] linea : lineas) { %>
        agregarLinea("<%= linea[0] %>", <%= linea[1] %>, <%= linea[2] %>);
    <% } %>
    };
</script>
</body>
</html>