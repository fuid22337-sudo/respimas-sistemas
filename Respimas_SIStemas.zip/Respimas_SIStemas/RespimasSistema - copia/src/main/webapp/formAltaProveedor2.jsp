<%-- 
    Document   : formAltaProveedor2
    Created on : 29 may 2026, 7:39:38 p.m.
    Author     : ianac
--%>
 <%
    if (session == null || session.getAttribute("logueado") == null) {
        response.sendRedirect("login.jsp");
        return;
    }
%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ include file="header.jsp" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Nuevo Proveedor</title>
    <link rel="stylesheet" type="text/css" href="estilos.css">
    <style>
        form { max-width: 600px; }
    </style>
</head>
<body>
<div class="container">
    <h2>Registrar Proveedor</h2>
    <form action="ServInsProveedor" method="post">
        <label>RFC:</label>
        <input type="text" name="rfc" required>

        <label>Nombre:</label>
        <input type="text" name="nombre" required>

        <label>Condiciones Pago:</label>
        <input type="text" name="condiciones_pago">

        <label>Contacto:</label>
        <input type="text" name="contacto">

        <label>Datos Bancarios:</label>
        <textarea name="datos_bancarios" rows="3"></textarea>

        <input type="submit" value="Guardar Proveedor">
    </form>
    <br>
    <a href="ServAllProveedores" class="volver">← Cancelar</a>
</div>
</body>
</html>