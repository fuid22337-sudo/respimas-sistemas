<%-- 
    Document   : formAltaCliente2
    Created on : 29 may 2026, 7:18:21 p.m.
    Author     : ianac
--%>
 <%
    if (session == null || session.getAttribute("logueado") == null) {
        response.sendRedirect("login.jsp");
        return;
    }
%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ include file="header.jsp" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Nuevo Cliente</title>
    <link rel="stylesheet" type="text/css" href="estilos.css">
    <style>
        form { max-width: 600px; }
    </style>
</head>
<body>
<div class="container">
    <h2>Registrar Cliente</h2>
    <form action="ServInsCliente" method="post">
        <label>RFC:</label>
        <input type="text" name="rfc" required>

        <label>Nombre Comercial:</label>
        <input type="text" name="nombre_comercial" required>

        <label>Razón Social:</label>
        <input type="text" name="razon_social">

        <label>Dirección:</label>
        <input type="text" name="direccion">

        <label>Teléfono:</label>
        <input type="text" name="telefono">

        <label>Contacto:</label>
        <input type="text" name="contacto">

        <label>Límite de Crédito:</label>
        <input type="number" step="0.01" name="limite_credito" value="0">

        <input type="submit" value="Guardar Cliente">
    </form>
    <br>
    <a href="ServAllClientes" class="volver">← Ver todos los clientes</a>
</div>
</body>
</html>