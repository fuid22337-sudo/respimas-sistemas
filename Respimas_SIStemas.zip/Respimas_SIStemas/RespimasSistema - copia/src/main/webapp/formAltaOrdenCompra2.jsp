<%-- 
    Document   : formAltaOrdenCompra2
    Created on : 29 may 2026, 7:35:50 p.m.
    Author     : ianac
--%>
 <%
    if (session == null || session.getAttribute("logueado") == null) {
        response.sendRedirect("login.jsp");
        return;
    }
%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ include file="header.jsp" %>
<%@page import="java.sql.*, com.mycompany.respimas.ConexionBD" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Nueva Orden de Compra</title>
    <link rel="stylesheet" type="text/css" href="estilos.css">
    <style>
        form { max-width: 800px; }
    </style>
    <script>
        var productos = [];
        <%
            try (Connection conn = ConexionBD.getConnection();
                 Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery("SELECT SKU, descripcion, precio_proveedor FROM PRODUCTO ORDER BY SKU")) {
                while (rs.next()) {
        %>
                    productos.push({ sku: "<%= rs.getString("SKU") %>", desc: "<%= rs.getString("descripcion") %>", precio: <%= rs.getDouble("precio_proveedor") %> });
        <%      }
            } catch (Exception e) { }
        %>

        function agregarLinea() {
            var tbody = document.getElementById("lineas");
            var fila = tbody.insertRow();
            var celda1 = fila.insertCell(0);
            var celda2 = fila.insertCell(1);
            var celda3 = fila.insertCell(2);
            var celda4 = fila.insertCell(3);

            var select = document.createElement("select");
            select.name = "sku[]";
            select.required = true;
            select.innerHTML = '<option value="">-- Seleccione --</option>';
            productos.forEach(function(p) {
                var opt = document.createElement("option");
                opt.value = p.sku;
                opt.textContent = p.sku + " - " + p.desc;
                opt.setAttribute("data-precio", p.precio);
                select.appendChild(opt);
            });

            var inputCant = document.createElement("input");
            inputCant.type = "number"; inputCant.name = "cantidad[]"; inputCant.min = "1"; inputCant.value = "1"; inputCant.required = true;

            var inputPrecio = document.createElement("input");
            inputPrecio.type = "number"; inputPrecio.name = "precio[]"; inputPrecio.step = "0.01"; inputPrecio.required = true;

            select.addEventListener("change", function() {
                var opt = this.options[this.selectedIndex];
                var precio = opt.getAttribute("data-precio");
                inputPrecio.value = precio ? precio : "";
            });

            var btnQuitar = document.createElement("button");
            btnQuitar.type = "button"; btnQuitar.textContent = "Quitar";
            btnQuitar.onclick = function() { this.parentElement.parentElement.remove(); };

            celda1.appendChild(select);
            celda2.appendChild(inputCant);
            celda3.appendChild(inputPrecio);
            celda4.appendChild(btnQuitar);
        }
    </script>
</head>
<body>
<div class="container">
    <h2>Registrar Orden de Compra</h2>
    <form action="ServInsOrdenCompra" method="post">
        <label>Núm. Orden:</label>
        <input type="text" name="num_orden" required>

        <label>Fecha:</label>
        <input type="date" name="fecha" required>

        <label>Proveedor:</label>
        <select name="proveedor_RFC" required>
            <option value="">-- Seleccione un proveedor --</option>
            <%
                try (Connection conn = ConexionBD.getConnection();
                     Statement stmt = conn.createStatement();
                     ResultSet rs = stmt.executeQuery("SELECT RFC, nombre FROM PROVEEDOR ORDER BY nombre")) {
                    while (rs.next()) {
            %>
                        <option value="<%= rs.getString("RFC") %>"><%= rs.getString("nombre") %></option>
            <%      }
                } catch (Exception e) { }
            %>
        </select>

        <label>Productos:</label>
        <table id="tablaLineas">
            <thead><tr><th>Producto</th><th>Cantidad</th><th>Precio Unitario</th><th></th></tr></thead>
            <tbody id="lineas"></tbody>
        </table>
        <button type="button" onclick="agregarLinea()">➕ Agregar línea</button><br><br>

        <label>Estatus:</label>
        <select name="estatus">
            <option value="Enviada">Enviada</option>
            <option value="Recibida">Recibida</option>
            <option value="Cancelada">Cancelada</option>
        </select>

        <input type="submit" value="Guardar">
    </form>
    <br><a href="ServAllOrdenesCompra" class="volver">← Cancelar</a>
</div>
</body>
</html>