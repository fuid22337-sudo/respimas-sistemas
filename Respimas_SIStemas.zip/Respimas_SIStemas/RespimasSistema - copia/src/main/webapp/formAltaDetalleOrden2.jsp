<%-- 
    Document   : formAltaDetalleOrden2
    Created on : 29 may 2026, 1:40:14 p.m.
    Author     : ianac
--%>
<%
    if (session == null || session.getAttribute("logueado") == null) {
        response.sendRedirect("login.jsp");
        return;
    }
%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ include file="header.jsp" %>
<%@page import="java.sql.*, com.mycompany.respimas.ConexionBD" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Agregar Producto a Orden</title>
    <link rel="stylesheet" type="text/css" href="estilos.css">
    <style>
        form { max-width: 600px; }
    </style>
    <script>
        // Arreglo con productos (SKU, descripción y precio_proveedor)
        var productos = [];
        <%
            try (Connection connProd = ConexionBD.getConnection();
                 Statement stmtProd = connProd.createStatement();
                 ResultSet rsProd = stmtProd.executeQuery("SELECT SKU, descripcion, precio_proveedor FROM PRODUCTO ORDER BY SKU")) {
                while (rsProd.next()) {
        %>
                    productos.push({
                        sku: "<%= rsProd.getString("SKU") %>",
                        desc: "<%= rsProd.getString("descripcion").replace("\"", "\\\"") %>",
                        precio: <%= rsProd.getDouble("precio_proveedor") %>
                    });
        <%
                }
            } catch (Exception e) { }
        %>

        window.onload = function() {
            var selectSku = document.getElementById("sku");
            // Llenar el desplegable
            if (productos.length > 0) {
                selectSku.innerHTML = '<option value="">-- Seleccione un producto --</option>';
                productos.forEach(function(p) {
                    var opt = document.createElement("option");
                    opt.value = p.sku;
                    opt.textContent = p.sku + " - " + p.desc;
                    opt.setAttribute("data-precio", p.precio);
                    selectSku.appendChild(opt);
                });
            } else {
                selectSku.innerHTML = '<option value="">Error al cargar productos</option>';
            }

            // Autocompletar precio al seleccionar producto
            selectSku.addEventListener("change", function() {
                var selectedOption = this.options[this.selectedIndex];
                var precio = selectedOption.getAttribute("data-precio");
                document.getElementById("precio_unitario").value = precio ? precio : "";
            });
        };
    </script>
</head>
<body>
<div class="container">
    <h2>Agregar Producto a Orden</h2>
    <form action="ServInsDetalleOrden" method="post">
        <label>Núm. Orden:</label>
        <input type="text" name="num_orden" value="<%= request.getParameter("num_orden") %>" readonly required>

        <label>Producto:</label>
        <select id="sku" name="sku" required>
            <option value="">Cargando productos...</option>
        </select>

        <label>Cantidad:</label>
        <input type="number" name="cantidad" min="1" value="1" required>

        <label>Precio Unitario:</label>
        <input type="number" step="0.01" id="precio_unitario" name="precio_unitario" required>

        <input type="submit" value="Agregar Producto">
    </form>
    <br>
    <a href="javascript:history.back()" class="volver">← Cancelar</a>
</div>
</body>
</html>