<%-- 
    Document   : formAltaUsuario
    Created on : 3 jun 2026, 5:31:45 p.m.
    Author     : ianac
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
    HttpSession sesion = request.getSession(false);
    if (sesion == null || sesion.getAttribute("logueado") == null) {
        response.sendRedirect("login.jsp?error=2");
        return;
    }
    String usuario = (String) sesion.getAttribute("usuario");
    String nombre = (String) sesion.getAttribute("nombre");
    String rol = (String) sesion.getAttribute("rol");
    if (nombre == null || nombre.trim().isEmpty()) {
        nombre = usuario;
    }
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RESPIMAS | Panel de Control</title>
    <link rel="stylesheet" type="text/css" href="estilos.css">
</head>
<body>
<div class="app-layout">
    <!-- MENÚ LATERAL -->
    <aside class="sidebar" id="sidebarMenu">
        <div class="sidebar-header">
            <span class="sidebar-logo">⚙️</span>
            <span>RESPIMAS</span>
        </div>
        <nav class="sidebar-nav">
            <div class="sidebar-section">
                <span class="sidebar-section-title">Principal</span>
                <a href="ServAllFacturasVenta" class="sidebar-link">🧾 Facturas de Venta</a>
                <a href="ServAllOrdenesCompra" class="sidebar-link">🛒 Órdenes de Compra</a>
                <a href="ServAllAbonos" class="sidebar-link">💵 Abonos</a>
            </div>
            <div class="sidebar-section">
                <span class="sidebar-section-title">Administración</span>
                <a href="ServAllClientes" class="sidebar-link">👥 Clientes</a>
                <a href="ServAllProductos" class="sidebar-link">📦 Productos</a>
                <a href="ServAllProveedores" class="sidebar-link">🚚 Proveedores</a>
            </div>
            <div class="sidebar-section">
                <span class="sidebar-section-title">Operaciones</span>
                <a href="ServAllFacturasCompra" class="sidebar-link">📄 Facturas de Compra</a>
                <a href="ServAllMovimientosInventario" class="sidebar-link">📊 Movimientos Inventario</a>
            </div>
            <div class="sidebar-section">
                <span class="sidebar-section-title">Documentos</span>
                <a href="ServAllCotizaciones" class="sidebar-link">📝 Cotizaciones</a>
                <a href="ServAllDetalleCotizacion" class="sidebar-link">🔍 Detalle Cotizaciones</a>
                <a href="ServConsultasEspeciales" class="sidebar-link">📈 Consultas</a>
            </div>
            <% if ("admin".equals(rol)) { %>
            <div class="sidebar-section">
                <span class="sidebar-section-title">Sistema</span>
                <a href="ServAllUsuarios" class="sidebar-link">🔐 Usuarios</a>
            </div>
            <% } %>
        </nav>
    </aside>

    <!-- CONTENIDO PRINCIPAL -->
    <div class="main-content">
        <!-- HEADER -->
        <header class="main-header">
            <button class="toggle-sidebar-btn" id="toggleSidebarBtn" title="Mostrar / ocultar menú">
                ☰
            </button>
            <div class="header-right">
                <div class="user-info">
                    <span class="user-avatar">👤</span>
                    <div>
                        <span class="user-name"><%= nombre %></span>
                        <span class="user-role"><%= rol %></span>
                    </div>
                </div>
                <a href="ServLogout" class="logout-btn" onclick="return confirm('¿Cerrar sesión?')" title="Cerrar sesión">
                    Cerrar sesión
                </a>
            </div>
        </header>

        <!-- PANEL DE BOTONES -->
        <div class="dashboard-content">
            <div class="welcome-section">
                <h1>Panel de Control</h1>
                <p>Acceso rápido a los módulos principales del sistema</p>
            </div>
            <div class="module-grid">
                <a href="ServAllFacturasVenta" class="module-card">
                    <span class="module-icon">🧾</span>
                    <span class="module-title">Facturas de Venta</span>
                    <span class="module-desc">Crear, editar y consultar ventas</span>
                </a>
                <a href="ServAllClientes" class="module-card">
                    <span class="module-icon">👥</span>
                    <span class="module-title">Clientes</span>
                    <span class="module-desc">Gestionar cartera de clientes</span>
                </a>
                <a href="ServAllProductos" class="module-card">
                    <span class="module-icon">📦</span>
                    <span class="module-title">Productos</span>
                    <span class="module-desc">Catálogo de productos</span>
                </a>
                <a href="ServAllOrdenesCompra" class="module-card">
                    <span class="module-icon">🛒</span>
                    <span class="module-title">Órdenes de Compra</span>
                    <span class="module-desc">Pedidos a proveedores</span>
                </a>
                <a href="ServAllProveedores" class="module-card">
                    <span class="module-icon">🚚</span>
                    <span class="module-title">Proveedores</span>
                    <span class="module-desc">Directorio de proveedores</span>
                </a>
                <a href="ServAllAbonos" class="module-card">
                    <span class="module-icon">💵</span>
                    <span class="module-title">Abonos</span>
                    <span class="module-desc">Registro de pagos</span>
                </a>
            </div>
        </div>

        <!-- PIE DE PÁGINA -->
        <footer class="main-footer">
            <span>© 2026 RESPIMAS</span>
            <span>Versión 1.0</span>
        </footer>
    </div>
</div>

<script>
    const sidebar = document.getElementById('sidebarMenu');
    const toggleBtn = document.getElementById('toggleSidebarBtn');

    function toggleSidebar() {
        sidebar.classList.toggle('collapsed');
        toggleBtn.textContent = sidebar.classList.contains('collapsed') ? '☰' : '☰';
    }

    toggleBtn.addEventListener('click', toggleSidebar);

    // Cerrar menú al hacer clic en un enlace en móviles
    if (window.innerWidth <= 780) {
        document.querySelectorAll('.sidebar-link').forEach(link => {
            link.addEventListener('click', () => {
                if (!sidebar.classList.contains('collapsed')) {
                    setTimeout(() => sidebar.classList.add('collapsed'), 150);
                }
            });
        });
    }
</script>
</body>
</html>