<%-- 
    Document   : formAltaUsuario
    Created on : 3 jun 2026, 5:31:45 p.m.
    Author     : ianac
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
    if (session == null || session.getAttribute("logueado") == null) {
        response.sendRedirect("login.jsp");
        return;
    }
    String rol = (String) session.getAttribute("rol");
    if (!"admin".equals(rol)) {
        response.sendRedirect("index.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Nuevo Usuario - RESPIMAS</title>
    <link rel="stylesheet" type="text/css" href="estilos.css">
    <style>
        form { max-width: 500px; }
    </style>
</head>
<body>
<div class="container">
    <h2>Registrar Nuevo Usuario</h2>
    <form action="ServInsUsuario" method="post">
        <label>Nombre de usuario:</label>
        <input type="text" name="username" required>

        <label>Contraseña:</label>
        <input type="password" name="password" required>

        <label>Nombre completo:</label>
        <input type="text" name="nombre">

        <label>Rol:</label>
        <select name="rol">
            <option value="usuario">Usuario</option>
            <option value="admin">Administrador</option>
        </select>

        <input type="submit" value="Crear Usuario">
    </form>
    <br>
    <a href="ServAllUsuarios" class="volver">← Volver al listado</a>
</div>
</body>
</html>