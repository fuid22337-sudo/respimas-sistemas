<%-- 
    Document   : formAltaProducto
    Created on : 29 may 2026, 7:37:56 p.m.
    Author     : ianac
--%>
 <%
    if (session == null || session.getAttribute("logueado") == null) {
        response.sendRedirect("login.jsp");
        return;
    }
%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ include file="header.jsp" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Nuevo Producto</title>
    <link rel="stylesheet" type="text/css" href="estilos.css">
    <style>
        form { max-width: 600px; }
    </style>
</head>
<body>
<div class="container">
    <h2>Registrar Producto</h2>
    <form action="ServInsProducto" method="post">
        <label>SKU:</label>
        <input type="text" name="sku" required>

        <label>Catálogo:</label>
        <input type="text" name="catalogo">

        <label>Código SAT:</label>
        <input type="text" name="codigo_sat">

        <label>Descripción:</label>
        <textarea name="descripcion" rows="3"></textarea>

        <label>Marca:</label>
        <input type="text" name="marca">

        <label>Precio Cliente:</label>
        <input type="number" step="0.01" name="precio_cliente" required>

        <label>Precio Proveedor:</label>
        <input type="number" step="0.01" name="precio_proveedor" required>

        <label>Stock Mínimo:</label>
        <input type="number" name="stock_minimo" value="0">

        <label>Existencia Actual:</label>
        <input type="number" name="existencia_actual" value="0">

        <input type="submit" value="Guardar Producto">
    </form>
    <br>
    <a href="ServAllProductos" class="volver">← Cancelar</a>
</div>
</body>
</html>

