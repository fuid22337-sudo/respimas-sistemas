<%-- 
    Document   : formAltaMovimientoInventario2
    Created on : 29 may 2026, 7:33:44 p.m.
    Author     : ianac
--%>
 <%
    if (session == null || session.getAttribute("logueado") == null) {
        response.sendRedirect("login.jsp");
        return;
    }
%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ include file="header.jsp" %>
<!DOCTYPE html>
<html>
<head>
    <title>Nuevo Movimiento de Inventario</title>
    <style>
        body { font-family: Arial; margin: 20px; }
        .container { max-width: 500px; margin: auto; }
        input, select { width: 100%; padding: 8px; margin: 5px 0 15px 0; }
        button { background: blue; color: white; padding: 10px; border: none; cursor: pointer; width: 100%; }
    </style>
</head>
<body>
<div class="container">
    <h2>Registrar Movimiento de Inventario</h2>
    <form action="ServInsMovimientoInventario" method="post">
        Fecha: <input type="date" name="fecha" required><br>
        Tipo:
        <select name="tipo" required>
            <option value="entrada">Entrada (ingreso al almacén)</option>
            <option value="salida">Salida (despacho)</option>
        </select><br>
        Cantidad: <input type="number" name="cantidad" required><br>
        Referencia (opcional): <input type="text" name="referencia" placeholder="Ej: factura, orden, etc."><br>
        SKU del Producto: <input type="text" name="sku" required><br>
        <button type="submit">Guardar Movimiento</button>
    </form>
    <br>
    <a href="ServAllMovimientosInventario">Ver todos los movimientos</a>
</div>
</body>
</html>