<%-- 
    Document   : formAltaDetalleCotizacion2
    Created on : 29 may 2026, 7:24:03 p.m.
    Author     : ianac
--%>
 <%
    if (session == null || session.getAttribute("logueado") == null) {
        response.sendRedirect("login.jsp");
        return;
    }
%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ include file="header.jsp" %>
<%@page import="java.sql.*, com.mycompany.respimas.ConexionBD" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Agregar Producto a Cotización</title>
    <link rel="stylesheet" type="text/css" href="estilos.css">
    <style>
        form { max-width: 600px; }
    </style>
    <script>
        // Obtener parámetros de la URL para precargar el número de cotización
        function getParameterByName(name) {
            const urlParams = new URLSearchParams(window.location.search);
            return urlParams.get(name);
        }

        // Productos con sus precios (cargados desde JSP)
        var productos = [];
        <%
            try (Connection conn = ConexionBD.getConnection();
                 Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery("SELECT SKU, descripcion, precio_cliente FROM PRODUCTO ORDER BY SKU")) {
                while (rs.next()) {
        %>
                    productos.push({
                        sku: "<%= rs.getString("SKU") %>",
                        desc: "<%= rs.getString("descripcion").replace("\"", "\\\"") %>",
                        precio: <%= rs.getDouble("precio_cliente") %>
                    });
        <%
                }
            } catch (Exception e) { }
        %>

        window.onload = function() {
            // Precargar número de cotización desde la URL
            const numCotizacion = getParameterByName('num_cotizacion');
            if (numCotizacion) {
                document.getElementById('num_cotizacion').value = numCotizacion;
                document.getElementById('num_cotizacion').readOnly = true;
            }

            // Llenar el desplegable de productos
            var selectSku = document.getElementById('sku');
            if (productos.length > 0) {
                selectSku.innerHTML = '<option value="">-- Seleccione un producto --</option>';
                productos.forEach(function(p) {
                    var opt = document.createElement('option');
                    opt.value = p.sku;
                    opt.textContent = p.sku + ' - ' + p.desc;
                    opt.setAttribute('data-precio', p.precio);
                    selectSku.appendChild(opt);
                });
            } else {
                selectSku.innerHTML = '<option value="">Error al cargar productos</option>';
            }

            // Autocompletar precio al seleccionar producto
            selectSku.addEventListener('change', function() {
                var selectedOption = this.options[this.selectedIndex];
                var precio = selectedOption.getAttribute('data-precio');
                document.getElementById('precio_unitario').value = precio ? precio : '';
            });
        };
    </script>
</head>
<body>
<div class="container">
    <h2>Agregar Producto a Cotización</h2>
    <form action="ServInsDetalleCotizacion" method="post">
        <label>Número de Cotización:</label>
        <input type="text" id="num_cotizacion" name="num_cotizacion" required>

        <label>Producto:</label>
        <select id="sku" name="sku" required>
            <option value="">Cargando productos...</option>
        </select>

        <label>Cantidad:</label>
        <input type="number" name="cantidad" min="1" value="1" required>

        <label>Precio Unitario:</label>
        <input type="number" step="0.01" id="precio_unitario" name="precio_unitario" required>

        <input type="submit" value="Agregar Producto">
    </form>
    <br>
    <a href="ServAllCotizaciones" class="volver">← Cancelar</a>
</div>
</body>
</html>