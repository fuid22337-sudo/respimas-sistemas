<%-- 
    Document   : formAltaCotizacion2
    Created on : 29 may 2026, 4:35:57 p.m.
    Author     : ianac
--%>
 <%
    if (session == null || session.getAttribute("logueado") == null) {
        response.sendRedirect("login.jsp");
        return;
    }
%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ include file="header.jsp" %>
<%@page import="java.sql.*, com.mycompany.respimas.ConexionBD" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Nueva Cotización</title>
    <link rel="stylesheet" type="text/css" href="estilos.css">
    <style>
        form { max-width: 600px; }
    </style>
</head>
<body>
<div class="container">
    <h2>Registrar Cotización</h2>
    <form action="ServInsCotizacion" method="post">
        <label>Número de Cotización:</label>
        <input type="text" name="num_cotizacion" required>

        <label>Fecha:</label>
        <input type="date" name="fecha" required>

        <label>Vigencia:</label>
        <input type="date" name="vigencia">

        <label>Estatus:</label>
        <select name="estatus">
            <option value="Activa">Activa</option>
            <option value="Vencida">Vencida</option>
            <option value="Aceptada">Aceptada</option>
        </select>

        <label>Cliente:</label>
        <select name="cliente_RFC" required>
            <option value="">-- Seleccione un cliente --</option>
            <%
                try (Connection conn = ConexionBD.getConnection();
                     Statement stmt = conn.createStatement();
                     ResultSet rs = stmt.executeQuery("SELECT RFC, nombre_comercial FROM CLIENTE ORDER BY nombre_comercial")) {
                    while (rs.next()) {
            %>
                        <option value="<%= rs.getString("RFC") %>">
                            <%= rs.getString("nombre_comercial") %> (<%= rs.getString("RFC") %>)
                        </option>
            <%
                    }
                } catch (Exception e) {
                    out.println("<option disabled>Error al cargar clientes</option>");
                }
            %>
        </select>

        <input type="submit" value="Guardar Cotización">
    </form>
    <br>
    <a href="ServAllCotizaciones" class="volver">← Cancelar</a>
</div>
</body>
</html>