<%-- 
    Document   : formAltaFacturaVenta2
    Created on : 29 may 2026, 7:31:38 p.m.
    Author     : ianac
--%>
 <%
    if (session == null || session.getAttribute("logueado") == null) {
        response.sendRedirect("login.jsp");
        return;
    }
%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ include file="header.jsp" %>
<%@page import="java.sql.*, com.mycompany.respimas.ConexionBD" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Nueva Factura de Venta</title>
    <link rel="stylesheet" type="text/css" href="estilos.css">
    <style>
        form { max-width: 700px; }
        .lineas-table { width: 100%; margin-bottom: 15px; }
    </style>
    <script>
        // Arreglo con productos (SKU, descripción y precio_cliente)
        var productos = [];
        <%
            try (Connection connProd = ConexionBD.getConnection();
                 Statement stmtProd = connProd.createStatement();
                 ResultSet rsProd = stmtProd.executeQuery("SELECT SKU, descripcion, precio_cliente FROM PRODUCTO ORDER BY SKU")) {
                while (rsProd.next()) {
        %>
                    productos.push({
                        sku: "<%= rsProd.getString("SKU") %>",
                        desc: "<%= rsProd.getString("descripcion").replace("\"", "\\\"") %>",
                        precio: <%= rsProd.getDouble("precio_cliente") %>
                    });
        <%
                }
            } catch (Exception e) { }
        %>

        function agregarLinea() {
            var tbody = document.getElementById("lineas");
            var fila = tbody.insertRow();

            var celda1 = fila.insertCell(0);
            var celda2 = fila.insertCell(1);
            var celda3 = fila.insertCell(2);
            var celda4 = fila.insertCell(3);

            // Crear select de productos
            var select = document.createElement("select");
            select.name = "sku[]";
            select.required = true;

            if (productos.length > 0) {
                var optDefault = document.createElement("option");
                optDefault.value = "";
                optDefault.textContent = "-- Seleccione --";
                select.appendChild(optDefault);

                for (var i = 0; i < productos.length; i++) {
                    var opt = document.createElement("option");
                    opt.value = productos[i].sku;
                    opt.textContent = productos[i].sku + " - " + productos[i].desc;
                    opt.setAttribute("data-precio", productos[i].precio);
                    select.appendChild(opt);
                }
            } else {
                var optErr = document.createElement("option");
                optErr.value = "";
                optErr.textContent = "Error al cargar productos";
                select.appendChild(optErr);
            }

            // Crear inputs de cantidad y precio
            var inputCantidad = document.createElement("input");
            inputCantidad.type = "number";
            inputCantidad.name = "cantidad[]";
            inputCantidad.min = "1";
            inputCantidad.value = "1";
            inputCantidad.required = true;

            var inputPrecio = document.createElement("input");
            inputPrecio.type = "number";
            inputPrecio.name = "precio[]";
            inputPrecio.step = "0.01";
            inputPrecio.required = true;

            // Evento: al cambiar el producto, poner su precio en el input
            select.addEventListener("change", function() {
                var selectedOption = this.options[this.selectedIndex];
                var precio = selectedOption.getAttribute("data-precio");
                if (precio) {
                    inputPrecio.value = precio;
                } else {
                    inputPrecio.value = "";
                }
            });

            // Botón quitar
            var btnQuitar = document.createElement("button");
            btnQuitar.type = "button";
            btnQuitar.textContent = "Quitar";
            btnQuitar.onclick = function() {
                this.parentElement.parentElement.remove();
            };

            celda1.appendChild(select);
            celda2.appendChild(inputCantidad);
            celda3.appendChild(inputPrecio);
            celda4.appendChild(btnQuitar);
        }
    </script>
</head>
<body>
<div class="container">
    <h2>Registrar Factura de Venta</h2>
    <form action="ServInsFacturaVenta" method="post">
        <label>Folio:</label>
        <input type="text" name="folio" required>

        <label>Fecha:</label>
        <input type="date" name="fecha" required>

        <label>Cliente:</label>
        <select name="cliente_RFC" required>
            <option value="">-- Seleccione un cliente --</option>
            <%
                try (Connection connCli = ConexionBD.getConnection();
                     Statement stmtCli = connCli.createStatement();
                     ResultSet rsCli = stmtCli.executeQuery("SELECT RFC, nombre_comercial FROM CLIENTE ORDER BY nombre_comercial")) {
                    while (rsCli.next()) {
            %>
                        <option value="<%= rsCli.getString("RFC") %>">
                            <%= rsCli.getString("nombre_comercial") %> (<%= rsCli.getString("RFC") %>)
                        </option>
            <%
                    }
                } catch (Exception e) {
                    out.println("<option disabled>Error al cargar clientes: " + e.getMessage() + "</option>");
                }
            %>
        </select>

        <label>Detalle de productos:</label>
        <table class="lineas-table">
            <thead><tr><th>Producto</th><th>Cantidad</th><th>Precio Unitario</th><th></th></tr></thead>
            <tbody id="lineas"></tbody>
        </table>
        <button type="button" onclick="agregarLinea()">➕ Agregar línea</button>

        <label>Estatus:</label>
        <select name="estatus">
            <option value="Pendiente">Pendiente</option>
            <option value="Pagada">Pagada</option>
            <option value="Cancelada">Cancelada</option>
        </select>

        <label>Fecha Pago:</label>
        <input type="date" name="fecha_pago">

        <label>Movimiento Banco:</label>
        <input type="text" name="movimiento_banco">

        <input type="submit" value="Guardar">
    </form>
    <br><a href="ServAllFacturasVenta" class="volver">← Cancelar</a>
</div>
</body>
</html>