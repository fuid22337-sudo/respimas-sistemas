<%-- 
    Document   : formAltaFacturaCompra2
    Created on : 29 may 2026, 7:29:13 p.m.
    Author     : ianac
--%>
 <%
    if (session == null || session.getAttribute("logueado") == null) {
        response.sendRedirect("login.jsp");
        return;
    }
%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ include file="header.jsp" %>
<%@page import="java.sql.*, com.mycompany.respimas.ConexionBD" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Nueva Factura de Compra</title>
    <link rel="stylesheet" type="text/css" href="estilos.css">
    <style>
        form { max-width: 600px; }
        .info-orden { background: #f0f8ff; padding: 12px; border-radius: 6px; margin: 10px 0; }
    </style>
</head>
<body>
<div class="container">
    <h2>Registrar Factura de Compra</h2>
    <form action="ServInsFacturaCompra" method="post">
        <label>Folio Proveedor:</label>
        <input type="text" name="folio_proveedor" id="folio_proveedor" required>

        <label>Fecha:</label>
        <input type="date" name="fecha" id="fecha" value="<%= java.time.LocalDate.now() %>" required>

        <label>Orden de Compra asociada:</label>
        <select name="num_orden" id="num_orden" onchange="cargarDatosOrden()">
            <option value="">-- Sin orden (compra directa) --</option>
            <%
                try (Connection conn = ConexionBD.getConnection();
                     Statement stmt = conn.createStatement();
                     ResultSet rs = stmt.executeQuery(
                         "SELECT o.num_orden, o.fecha, o.total, o.subtotal, p.nombre " +
                         "FROM ORDEN_COMPRA o " +
                         "INNER JOIN PROVEEDOR p ON o.proveedor_RFC = p.RFC " +
                         "WHERE o.estatus = 'Enviada' " +
                         "AND o.num_orden NOT IN (SELECT num_orden FROM FACTURA_COMPRA WHERE num_orden IS NOT NULL) " +
                         "ORDER BY o.fecha DESC")) {
                    while (rs.next()) {
            %>
                        <option value="<%= rs.getString("num_orden") %>"
                                data-total="<%= rs.getDouble("total") %>"
                                data-iva="<%= rs.getDouble("total") - rs.getDouble("subtotal") %>"
                                data-fecha="<%= rs.getDate("fecha") %>">
                            <%= rs.getString("num_orden") %> - <%= rs.getString("nombre") %> (Total: <%= rs.getDouble("total") %>)
                        </option>
            <%
                    }
                } catch (Exception e) {
                    out.println("<option disabled>Error al cargar órdenes</option>");
                }
            %>
        </select>

        <div id="infoOrden" class="info-orden" style="display:none;">
            <p><strong>Total de la orden:</strong> $<span id="totalOrden"></span></p>
            <p><strong>IVA:</strong> $<span id="ivaOrden"></span></p>
        </div>

        <label>Monto Total:</label>
        <input type="number" step="0.01" name="monto_total" id="monto_total" required>

        <label>IVA:</label>
        <input type="number" step="0.01" name="iva" id="iva" value="0">

        <label>Fecha Vencimiento:</label>
        <input type="date" name="fecha_vencimiento" id="fecha_vencimiento" required>

        <label>Fecha Pago:</label>
        <input type="date" name="fecha_pago">

        <label>Estatus:</label>
        <select name="estatus">
            <option value="Pendiente">Pendiente</option>
            <option value="Pagada">Pagada</option>
            <option value="Cancelada">Cancelada</option>
        </select>

        <input type="submit" value="Guardar">
    </form>
    <br><a href="ServAllFacturasCompra" class="volver">← Cancelar</a>
</div>

<script>
    function cargarDatosOrden() {
        var select = document.getElementById("num_orden");
        var selectedOption = select.options[select.selectedIndex];
        var infoDiv = document.getElementById("infoOrden");
        var montoInput = document.getElementById("monto_total");
        var ivaInput = document.getElementById("iva");
        var vencInput = document.getElementById("fecha_vencimiento");
        var folioInput = document.getElementById("folio_proveedor");

        if (selectedOption.value === "") {
            infoDiv.style.display = "none";
            montoInput.value = "";
            ivaInput.value = "0";
            folioInput.value = "";
            return;
        }

        var total = selectedOption.getAttribute("data-total");
        var iva = selectedOption.getAttribute("data-iva");

        document.getElementById("totalOrden").textContent = total;
        document.getElementById("ivaOrden").textContent = iva;
        infoDiv.style.display = "block";

        montoInput.value = total;
        ivaInput.value = iva;
        folioInput.value = "FAC-" + selectedOption.value;

        var hoy = new Date();
        hoy.setDate(hoy.getDate() + 30);
        vencInput.value = hoy.toISOString().split('T')[0];
    }
</script>
</body>
</html>
