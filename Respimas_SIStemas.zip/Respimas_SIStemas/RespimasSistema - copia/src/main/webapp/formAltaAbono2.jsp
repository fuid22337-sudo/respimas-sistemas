<%-- 
    Document   : formAltaAbono2
    Created on : 29 may 2026, 4:49:31 p.m.
    Author     : ianac
--%>
 <%
    if (session == null || session.getAttribute("logueado") == null) {
        response.sendRedirect("login.jsp");
        return;
    }
%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ include file="header.jsp" %>
<%@page import="java.sql.*, com.mycompany.respimas.ConexionBD" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Nuevo Abono</title>
    <link rel="stylesheet" type="text/css" href="estilos.css">
    <style>
        form { max-width: 550px; }
        .info-factura { background: #f0f8ff; padding: 12px; border-radius: 6px; margin-bottom: 15px; }
    </style>
</head>
<body>
<div class="container">
    <h2>Registrar Abono</h2>
    <form action="ServInsAbono" method="post" id="formAbono">
        <label>Fecha:</label>
        <input type="date" name="fecha" required>

        <label>Factura:</label>
        <select name="factura_folio" id="factura_folio" required>
            <option value="">-- Seleccione una factura pendiente --</option>
            <%
                try (Connection conn = ConexionBD.getConnection();
                     Statement stmt = conn.createStatement();
                     ResultSet rs = stmt.executeQuery(
                         "SELECT fv.folio, fv.monto_total, c.nombre_comercial, " +
                         "fv.monto_total - COALESCE((SELECT SUM(a.monto) FROM ABONO a WHERE a.factura_folio = fv.folio), 0) AS saldo " +
                         "FROM FACTURA_VENTA fv " +
                         "INNER JOIN CLIENTE c ON fv.cliente_RFC = c.RFC " +
                         "WHERE fv.estatus != 'Pagada' AND fv.estatus != 'Cancelada' " +
                         "ORDER BY fv.fecha DESC")) {
                    while (rs.next()) {
                        String folio = rs.getString("folio");
                        String cliente = rs.getString("nombre_comercial");
                        double total = rs.getDouble("monto_total");
                        double saldo = rs.getDouble("saldo");
            %>
                        <option value="<%= folio %>"
                                data-total="<%= total %>"
                                data-saldo="<%= saldo %>">
                            <%= folio %> - <%= cliente %> (Total: <%= total %>, Saldo: <%= saldo %>)
                        </option>
            <%
                    }
                } catch (Exception e) {
                    out.println("<option disabled>Error al cargar facturas</option>");
                }
            %>
        </select>

        <div id="infoFactura" class="info-factura" style="display: none;">
            <p><strong>Total factura:</strong> $<span id="totalFactura"></span></p>
            <p><strong>Saldo pendiente:</strong> $<span id="saldoPendiente"></span></p>
        </div>

        <label>Monto del abono:</label>
        <input type="number" step="0.01" name="monto" id="monto" required>

        <label>Referencia Bancaria:</label>
        <input type="text" name="referencia_bancaria">

        <input type="hidden" name="saldo_restante" id="saldo_restante">

        <input type="submit" value="Guardar">
    </form>
    <br><a href="ServAllAbonos" class="volver">← Cancelar</a>
</div>

<script>
    const selectFactura = document.getElementById('factura_folio');
    const infoDiv = document.getElementById('infoFactura');
    const totalSpan = document.getElementById('totalFactura');
    const saldoSpan = document.getElementById('saldoPendiente');
    const inputMonto = document.getElementById('monto');
    const inputSaldoRestante = document.getElementById('saldo_restante');

    selectFactura.addEventListener('change', function() {
        const selectedOption = this.options[this.selectedIndex];
        if (selectedOption.value === '') {
            infoDiv.style.display = 'none';
            inputSaldoRestante.value = '';
            return;
        }
        const total = parseFloat(selectedOption.getAttribute('data-total'));
        const saldoActual = parseFloat(selectedOption.getAttribute('data-saldo'));
        totalSpan.textContent = total.toFixed(2);
        saldoSpan.textContent = saldoActual.toFixed(2);
        infoDiv.style.display = 'block';
        // El saldo restante se calculará en el servlet, pero lo ponemos aquí como referencia
        inputSaldoRestante.value = (saldoActual - (parseFloat(inputMonto.value) || 0)).toFixed(2);
    });

    // Actualizar saldo restante cuando cambia el monto
    inputMonto.addEventListener('input', function() {
        const selectedOption = selectFactura.options[selectFactura.selectedIndex];
        if (!selectedOption || selectedOption.value === '') return;
        const saldoActual = parseFloat(selectedOption.getAttribute('data-saldo'));
        const monto = parseFloat(this.value) || 0;
        inputSaldoRestante.value = (saldoActual - monto).toFixed(2);
    });
</script>
</body>
</html>
