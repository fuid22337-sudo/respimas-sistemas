<%-- 
    Document   : header
    Created on : 3 jun 2026, 5:47:51 p.m.
    Author     : ianac
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
    HttpSession sesion = request.getSession(false);
    String usuario = (String) sesion.getAttribute("usuario");
    String nombre = (String) sesion.getAttribute("nombre");
    String rol = (String) sesion.getAttribute("rol");
    if (nombre == null || nombre.trim().isEmpty()) {
        nombre = usuario;
    }
%>
<header class="main-header">
    <div class="logo-area">
        <div class="company-text">
            <h2>RESPIMAS</h2>
        </div>
    </div>
    <div class="user-area">
        <span class="user-greeting">
            👋 <strong><%= nombre %></strong> (<%= usuario %>) | Rol: <%= rol %>
        </span>
        <a href="ServLogout" class="logout-btn" onclick="return confirm('¿Cerrar sesión?')">Cerrar sesión</a>
    </div>
</header>