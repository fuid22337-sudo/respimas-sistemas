CREATE DATABASE IF NOT EXISTS respimas_db;
USE respimas_db;

CREATE TABLE PRODUCTO (
    SKU VARCHAR(20) PRIMARY KEY,
    CATALOGO VARCHAR(20) UNIQUE,
    CODIGO_SAT VARCHAR(10),
    descripcion TEXT NOT NULL,
    marca VARCHAR(50),
    precio_cliente DECIMAL(10,2) NOT NULL,
    precio_proveedor DECIMAL(10,2) NOT NULL,
    stock_minimo INT DEFAULT 0,
    existencia_actual INT NOT NULL DEFAULT 0,
    CHECK (existencia_actual >= 0)
);

CREATE TABLE CLIENTE (
    RFC VARCHAR(13) PRIMARY KEY,
    nombre_comercial VARCHAR(100) NOT NULL,
    razon_social VARCHAR(150),
    direccion VARCHAR(200),
    telefono VARCHAR(20),
    contacto VARCHAR(100),
    limite_credito DECIMAL(12,2) DEFAULT 0
);

CREATE TABLE PROVEEDOR (
    RFC VARCHAR(13) PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    condiciones_pago VARCHAR(50),
    contacto VARCHAR(100),
    datos_bancarios TEXT
);

CREATE TABLE FACTURA_VENTA (
    folio VARCHAR(20) PRIMARY KEY,
    fecha DATE NOT NULL,
    monto_total DECIMAL(12,2) NOT NULL,
    estatus ENUM('Pendiente','Pagada','Cancelada') DEFAULT 'Pendiente',
    fecha_pago DATE,
    movimiento_banco VARCHAR(50),
    cliente_RFC VARCHAR(13) NOT NULL,
    FOREIGN KEY (cliente_RFC) REFERENCES CLIENTE(RFC) ON DELETE RESTRICT
);

CREATE TABLE ABONO (
    id_abono INT AUTO_INCREMENT PRIMARY KEY,
    fecha DATE NOT NULL,
    monto DECIMAL(12,2) NOT NULL,
    referencia_bancaria VARCHAR(50),
    saldo_restante DECIMAL(12,2) NOT NULL,
    factura_folio VARCHAR(20) NOT NULL,
    FOREIGN KEY (factura_folio) REFERENCES FACTURA_VENTA(folio) ON DELETE CASCADE,
    CHECK (monto > 0)
);


CREATE TABLE ORDEN_COMPRA (
    num_orden VARCHAR(20) PRIMARY KEY,
    fecha DATE NOT NULL,
    subtotal DECIMAL(12,2),
    IVA DECIMAL(12,2),
    total DECIMAL(12,2) NOT NULL,
    estatus ENUM('Enviada','Recibida','Cancelada') DEFAULT 'Enviada',
    proveedor_RFC VARCHAR(13) NOT NULL,
    FOREIGN KEY (proveedor_RFC) REFERENCES PROVEEDOR(RFC) ON DELETE RESTRICT
);


CREATE TABLE DETALLE_ORDEN (
    num_orden VARCHAR(20),
    SKU VARCHAR(20),
    cantidad INT NOT NULL,
    precio_unitario DECIMAL(10,2) NOT NULL,
    PRIMARY KEY (num_orden, SKU),
    FOREIGN KEY (num_orden) REFERENCES ORDEN_COMPRA(num_orden) ON DELETE CASCADE,
    FOREIGN KEY (SKU) REFERENCES PRODUCTO(SKU) ON DELETE RESTRICT,
    CHECK (cantidad > 0)
);


CREATE TABLE FACTURA_COMPRA (
    folio_proveedor VARCHAR(20) PRIMARY KEY,
    fecha DATE NOT NULL,
    monto_total DECIMAL(12,2) NOT NULL,
    IVA DECIMAL(12,2),
    fecha_vencimiento DATE NOT NULL,
    fecha_pago DATE,
    estatus ENUM('Pendiente','Pagada','Cancelada') DEFAULT 'Pendiente',
    num_orden VARCHAR(20) UNIQUE,
    FOREIGN KEY (num_orden) REFERENCES ORDEN_COMPRA(num_orden) ON DELETE SET NULL
);

CREATE TABLE MOVIMIENTO_INVENTARIO (
    id_mov INT AUTO_INCREMENT PRIMARY KEY,
    fecha DATE NOT NULL,
    tipo ENUM('entrada','salida') NOT NULL,
    cantidad INT NOT NULL,
    referencia VARCHAR(50),
    SKU VARCHAR(20) NOT NULL,
    FOREIGN KEY (SKU) REFERENCES PRODUCTO(SKU) ON DELETE CASCADE,
    CHECK (cantidad > 0)
);

CREATE TABLE COTIZACION (
    num_cotizacion VARCHAR(20) PRIMARY KEY,
    fecha DATE NOT NULL,
    vigencia DATE,
    estatus ENUM('Activa','Vencida','Aceptada') DEFAULT 'Activa',
    cliente_RFC VARCHAR(13) NOT NULL,
    FOREIGN KEY (cliente_RFC) REFERENCES CLIENTE(RFC) ON DELETE RESTRICT
);


CREATE TABLE DETALLE_COTIZACION (
    num_cotizacion VARCHAR(20),
    SKU VARCHAR(20),
    cantidad INT NOT NULL,
    precio_unitario DECIMAL(10,2) NOT NULL,
    PRIMARY KEY (num_cotizacion, SKU),
    FOREIGN KEY (num_cotizacion) REFERENCES COTIZACION(num_cotizacion) ON DELETE CASCADE,
    FOREIGN KEY (SKU) REFERENCES PRODUCTO(SKU) ON DELETE RESTRICT,
    CHECK (cantidad > 0)
);


CREATE INDEX idx_factura_cliente ON FACTURA_VENTA(cliente_RFC);
CREATE INDEX idx_movimiento_sku ON MOVIMIENTO_INVENTARIO(SKU);
CREATE INDEX idx_abono_factura ON ABONO(factura_folio);
CREATE INDEX idx_orden_proveedor ON ORDEN_COMPRA(proveedor_RFC);
CREATE INDEX idx_movimiento_fecha ON MOVIMIENTO_INVENTARIO(fecha);
CREATE INDEX idx_factura_fecha ON FACTURA_VENTA(fecha);
CREATE INDEX idx_cotizacion_cliente ON COTIZACION(cliente_RFC);